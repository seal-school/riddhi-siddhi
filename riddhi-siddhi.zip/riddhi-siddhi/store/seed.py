"""Sample catalogue so the store looks alive on day one. Delete or edit it from the admin panel."""
from . import db, utils

SAMPLE = [
    ("Women", [
        ("Cotton Straight Kurti", 799, 1299, True, "Soft everyday cotton with a clean straight cut. Easy to pair with leggings or palazzos.",
         "Machine wash cold. Do not bleach.", ["S", "M", "L", "XL"], ["Indigo", "Mustard"], 14),
        ("Printed Rayon Anarkali", 1299, 1999, True, "Flowy anarkali in breathable rayon with a block print border.",
         "Hand wash separately.", ["M", "L", "XL"], ["Teal"], 8),
        ("Everyday Cotton Top", 449, 699, False, "A relaxed top for work and weekends.",
         "Machine wash cold.", ["S", "M", "L"], ["White", "Rose"], 20),
    ]),
    ("Men", [
        ("Classic Oxford Shirt", 999, 1499, True, "Full sleeve cotton oxford with a regular fit. Works with jeans and chinos.",
         "Machine wash warm. Iron on medium.", ["38", "40", "42", "44"], ["White", "Sky"], 12),
        ("Relaxed Linen Shirt", 1199, 1799, False, "Light linen blend that stays cool in summer.",
         "Cold wash. Line dry.", ["M", "L", "XL"], ["Sand"], 6),
        ("Everyday Round Neck Tee", 349, 599, False, "Heavy 180 GSM cotton t-shirt that keeps its shape.",
         "Machine wash cold.", ["S", "M", "L", "XL", "XXL"], ["Black", "Navy"], 30),
    ]),
    ("Kids", [
        ("Kids Cotton Kurta Set", 899, 1399, True, "Kurta and pyjama set in soft cotton for festive days.",
         "Machine wash cold.", ["2-3Y", "4-5Y", "6-7Y"], ["Maroon"], 10),
        ("Kids Printed T-shirt", 299, 449, False, "Fun prints on soft cotton jersey.",
         "Machine wash cold.", ["2-3Y", "4-5Y", "6-7Y", "8-9Y"], ["Yellow"], 16),
    ]),
]


def seed():
    if db.q("SELECT 1 FROM products LIMIT 1", one=True):
        return "Catalogue already has products. Nothing was added."
    conn = db.get_db()
    for sort, (cat, items) in enumerate(SAMPLE):
        cur = conn.execute("INSERT OR IGNORE INTO categories(name, slug, sort) VALUES (?,?,?)",
                           (cat, utils.slugify(cat), sort))
        cid = conn.execute("SELECT id FROM categories WHERE slug = ?", (utils.slugify(cat),)).fetchone()["id"]
        for name, price, mrp, featured, desc, care, sizes, colors, stock in items:
            pid = conn.execute(
                "INSERT INTO products(category_id, name, slug, description, fabric_care, price, mrp, is_featured) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (cid, name, utils.unique_slug("products", name), desc, care, price, mrp, 1 if featured else 0)).lastrowid
            for color in colors:
                for i, size in enumerate(sizes):
                    qty = max(0, stock - i * 2)
                    vid = conn.execute("INSERT INTO variants(product_id, size, color, stock) VALUES (?,?,?,?)",
                                       (pid, size, color, qty)).lastrowid
                    conn.execute("INSERT INTO stock_log(variant_id, label, change, reason) VALUES (?,?,?,?)",
                                 (vid, "%s / %s / %s" % (name, size, color), qty, "Sample data"))
    conn.execute("INSERT OR IGNORE INTO coupons(code, kind, value, min_order, max_discount) VALUES ('WELCOME10','percent',10,799,200)")
    conn.commit()
    return "Added sample categories, products and the WELCOME10 coupon. Edit or delete them in the admin panel."
