"""Razorpay integration using only the standard library.

Flow: server creates a Razorpay order for the exact total -> browser opens Razorpay
Checkout -> browser posts the result back -> we verify the HMAC signature before
marking the order as paid. A webhook is a second safety net if the browser closes early.
"""
import base64
import hashlib
import hmac
import json
import urllib.error
import urllib.request

from flask import current_app


class PaymentError(Exception):
    pass


def create_order(amount_paise, receipt):
    key = current_app.config["RAZORPAY_KEY_ID"]
    secret = current_app.config["RAZORPAY_KEY_SECRET"]
    if not key or not secret:
        raise PaymentError("Razorpay is not configured.")
    body = json.dumps({"amount": int(amount_paise), "currency": "INR", "receipt": receipt}).encode()
    token = base64.b64encode(("%s:%s" % (key, secret)).encode()).decode()
    req = urllib.request.Request(
        "https://api.razorpay.com/v1/orders",
        data=body,
        method="POST",
        headers={"Content-Type": "application/json", "Authorization": "Basic " + token},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.load(resp)
    except (urllib.error.URLError, ValueError) as exc:
        raise PaymentError("Could not reach Razorpay: %s" % exc)
    if "id" not in data:
        raise PaymentError("Unexpected response from Razorpay.")
    return data


def _hmac(secret, message):
    return hmac.new(secret.encode(), message, hashlib.sha256).hexdigest()


def verify_signature(order_id, payment_id, signature):
    secret = current_app.config["RAZORPAY_KEY_SECRET"]
    if not (secret and order_id and payment_id and signature):
        return False
    expected = _hmac(secret, ("%s|%s" % (order_id, payment_id)).encode())
    return hmac.compare_digest(expected, signature)


def verify_webhook(raw_body, signature):
    secret = current_app.config["RAZORPAY_WEBHOOK_SECRET"]
    if not (secret and signature):
        return False
    return hmac.compare_digest(_hmac(secret, raw_body), signature)
