"""Order lifecycle. Stock is reserved the moment an order is created and handed back
if the order is cancelled, returned, or an online payment is never completed."""
from . import db
from .utils import price_order

PAYMENT_WINDOW_MINUTES = 45


class OutOfStock(Exception):
    def __init__(self, name):
        super().__init__(name)
        self.name = name


def log_event(order_id, text):
    db.get_db().execute("INSERT INTO order_events(order_id, text) VALUES (?, ?)", (order_id, text))


def log_stock(variant_id, label, change, reason):
    db.get_db().execute(
        "INSERT INTO stock_log(variant_id, label, change, reason) VALUES (?, ?, ?, ?)",
        (variant_id, label, change, reason),
    )


def variant_label(name, size, color):
    return "%s / %s%s" % (name, size, (" / " + color) if color else "")


def create_order(data, lines, coupon_code, method):
    """Create an order and reserve stock atomically. Raises OutOfStock if anything ran out."""
    conn = db.get_db()
    totals = price_order(lines, coupon_code, method)
    cod = method == "cod"
    try:
        for l in lines:
            cur = conn.execute(
                "UPDATE variants SET stock = stock - ? WHERE id = ? AND stock >= ?",
                (l["qty"], l["vid"], l["qty"]),
            )
            if cur.rowcount != 1:
                raise OutOfStock(l["name"])
        coupon = totals["coupon"]["code"] if totals["coupon"] else ""
        cur = conn.execute(
            """INSERT INTO orders(name, phone, email, address, city, state, pincode, subtotal, discount,
                   prepaid_discount, shipping, cod_fee, total, coupon_code, payment_method, payment_status,
                   status, customer_note)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                data["name"], data["phone"], data["email"], data["address"], data["city"], data["state"],
                data["pincode"], totals["subtotal"], totals["discount"], totals["prepaid_discount"],
                totals["shipping"], totals["cod_fee"], totals["total"], coupon, method,
                "cod_pending" if cod else "pending", "placed" if cod else "awaiting_payment",
                data.get("note", ""),
            ),
        )
        oid = cur.lastrowid
        order_no = "RS%d" % (1000 + oid)
        conn.execute("UPDATE orders SET order_no = ? WHERE id = ?", (order_no, oid))
        for l in lines:
            conn.execute(
                "INSERT INTO order_items(order_id, product_id, variant_id, name, size, color, price, qty) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (oid, l["pid"], l["vid"], l["name"], l["size"], l["color"], l["price"], l["qty"]),
            )
            log_stock(l["vid"], variant_label(l["name"], l["size"], l["color"]), -l["qty"], "Order " + order_no)
        if coupon:
            conn.execute("UPDATE coupons SET used_count = used_count + 1 WHERE code = ?", (coupon,))
        log_event(oid, "Order placed (%s)." % ("cash on delivery" if cod else "online payment pending"))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return order_no


def restore_stock(order_id, reason):
    """Return reserved stock to inventory once. Caller commits."""
    conn = db.get_db()
    order = conn.execute("SELECT stock_restored, coupon_code, order_no FROM orders WHERE id = ?", (order_id,)).fetchone()
    if not order or order["stock_restored"]:
        return
    for it in conn.execute("SELECT * FROM order_items WHERE order_id = ?", (order_id,)).fetchall():
        cur = conn.execute("UPDATE variants SET stock = stock + ? WHERE id = ?", (it["qty"], it["variant_id"]))
        if cur.rowcount:
            log_stock(it["variant_id"], variant_label(it["name"], it["size"], it["color"]), it["qty"],
                      "%s (%s)" % (reason, order["order_no"]))
    if order["coupon_code"]:
        conn.execute("UPDATE coupons SET used_count = MAX(0, used_count - 1) WHERE code = ?", (order["coupon_code"],))
    conn.execute("UPDATE orders SET stock_restored = 1 WHERE id = ?", (order_id,))


def mark_paid(order, payment_id=""):
    """Idempotent: safe to call from both the browser callback and the webhook."""
    conn = db.get_db()
    if order["payment_status"] == "paid":
        return
    if order["status"] == "cancelled":
        conn.execute(
            "UPDATE orders SET payment_status='paid', status='needs_review', razorpay_payment_id=?, "
            "paid_at=datetime('now'), updated_at=datetime('now') WHERE id=?",
            (payment_id, order["id"]),
        )
        log_event(order["id"], "Payment arrived after this order was released. Stock was already returned. "
                               "Check availability, then ship it or refund from the Razorpay dashboard.")
    else:
        new_status = "placed" if order["status"] == "awaiting_payment" else order["status"]
        conn.execute(
            "UPDATE orders SET payment_status='paid', status=?, razorpay_payment_id=?, "
            "paid_at=datetime('now'), updated_at=datetime('now') WHERE id=?",
            (new_status, payment_id, order["id"]),
        )
        log_event(order["id"], "Online payment received (%s)." % payment_id)
    conn.commit()


def release_expired(minutes=PAYMENT_WINDOW_MINUTES):
    """Cancel unpaid online orders after a while so held stock goes back on sale."""
    conn = db.get_db()
    rows = db.q(
        "SELECT id FROM orders WHERE status = 'awaiting_payment' AND created_at < datetime('now', ?)",
        ("-%d minutes" % minutes,),
    )
    for r in rows:
        restore_stock(r["id"], "Payment not completed")
        conn.execute(
            "UPDATE orders SET status='cancelled', payment_status='failed', updated_at=datetime('now') WHERE id=?",
            (r["id"],),
        )
        log_event(r["id"], "Cancelled automatically because the payment was not completed in time.")
    if rows:
        conn.commit()


def re_reserve(order_id):
    """Take stock again for an order whose stock had been returned (for example a late payment).
    Raises OutOfStock if any item is no longer available. Caller commits or rolls back."""
    conn = db.get_db()
    order = conn.execute("SELECT stock_restored, order_no FROM orders WHERE id = ?", (order_id,)).fetchone()
    if not order or not order["stock_restored"]:
        return
    items = conn.execute("SELECT * FROM order_items WHERE order_id = ?", (order_id,)).fetchall()
    for it in items:
        cur = conn.execute("UPDATE variants SET stock = stock - ? WHERE id = ? AND stock >= ?",
                           (it["qty"], it["variant_id"], it["qty"]))
        if cur.rowcount != 1:
            raise OutOfStock(it["name"])
        log_stock(it["variant_id"], variant_label(it["name"], it["size"], it["color"]), -it["qty"],
                  "Re-reserved (%s)" % order["order_no"])
    conn.execute("UPDATE orders SET stock_restored = 0 WHERE id = ?", (order_id,))
