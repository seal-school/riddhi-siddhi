import json
import re

from flask import (Blueprint, Response, abort, current_app, flash, jsonify, redirect, render_template,
                   request, send_from_directory, session, url_for)

from . import db, orders, payments, utils
from .utils import (SORTS, STATES, cart_lines, decorate, dispatch_info, normalize_phone, ok_lines,
                    price_order, product_count, product_query, sint, sorted_variants, to_int, valid_phone)

bp = Blueprint("shop", __name__)

CUSTOMER_FIELDS = ("name", "phone", "email", "address", "city", "state", "pincode")


# ------------------------------------------------------------------- helpers
def remember_order(order_no):
    seen = session.get("orders", [])
    if order_no not in seen:
        seen = (seen + [order_no])[-15:]
    session["orders"] = seen


def owned_order(order_no):
    order_no = (order_no or "").upper()
    if order_no not in session.get("orders", []):
        abort(404)
    order = db.q("SELECT * FROM orders WHERE order_no = ?", (order_no,), one=True)
    if not order:
        abort(404)
    return order


def recently_viewed(exclude=None, limit=4):
    ids = [i for i in session.get("rv", []) if i != exclude][:limit]
    if not ids:
        return []
    marks = ",".join("?" * len(ids))
    items = product_query("id IN (%s)" % marks, ids)
    items.sort(key=lambda p: ids.index(p["id"]))
    return items


# ---------------------------------------------------------------------- home
@bp.route("/")
def home():
    cats = db.q(
        """SELECT c.*,
             (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.is_active = 1) AS n,
             (SELECT i.filename FROM images i JOIN products p ON p.id = i.product_id
                WHERE p.category_id = c.id AND p.is_active = 1 ORDER BY p.is_featured DESC, p.id DESC, i.sort LIMIT 1) AS image
           FROM categories c ORDER BY c.sort, c.name"""
    )
    featured = product_query("stock > 0 AND is_featured = 1", order="id DESC", limit=8)
    popular = product_query("stock > 0 AND sold > 0", order="sold_week DESC, sold DESC", limit=8)
    newest = product_query("stock > 0", order="id DESC", limit=8)
    return render_template("home.html", cats=cats, featured=featured, popular=popular, newest=newest,
                           recent=recently_viewed(limit=4))


# ---------------------------------------------------------------------- shop
@bp.route("/shop")
def shop():
    q = request.args.get("q", "").strip()[:80]
    cat = request.args.get("category", "").strip()
    size = request.args.get("size", "").strip()
    sort = request.args.get("sort", "new")
    if sort not in SORTS:
        sort = "new"
    sale = bool(request.args.get("sale"))
    page = max(1, to_int(request.args.get("page"), 1))
    per = 12

    where, args = ["1=1"], []
    if q:
        where.append("(name LIKE ? OR description LIKE ? OR IFNULL(category_name,'') LIKE ?)")
        args += ["%" + q + "%"] * 3
    category = None
    if cat:
        category = db.q("SELECT * FROM categories WHERE slug = ?", (cat,), one=True)
        where.append("category_slug = ?")
        args.append(cat)
    if size:
        where.append("id IN (SELECT product_id FROM variants WHERE size = ? AND stock > 0)")
        args.append(size)
    if sale:
        where.append("mrp > price")
    clause = " AND ".join(where)

    total = product_count(clause, args)
    pg = utils.paginate(total, page, per)
    products = product_query(clause, args, order=SORTS[sort], limit=per, offset=(pg["page"] - 1) * per)
    sizes = sorted(
        {r["size"] for r in db.q(
            "SELECT DISTINCT v.size FROM variants v JOIN products p ON p.id = v.product_id "
            "WHERE v.stock > 0 AND p.is_active = 1")},
        key=utils.size_key,
    )
    keep = {k: v for k, v in request.args.items() if k != "page" and v}
    return render_template("shop.html", products=products, pg=pg, q=q, cat=cat, category=category, size=size,
                           sort=sort, sale=sale, sizes=sizes, keep=keep)


@bp.route("/product/<slug>")
def product(slug):
    rows = product_query("slug = ?", (slug,))
    if not rows:
        abort(404)
    p = rows[0]
    images = db.q("SELECT * FROM images WHERE product_id = ? ORDER BY sort, id", (p["id"],))
    variants = sorted_variants(db.q("SELECT id, size, color, stock FROM variants WHERE product_id = ?", (p["id"],)))
    reviews = db.q("SELECT * FROM reviews WHERE product_id = ? AND approved = 1 ORDER BY id DESC LIMIT 20", (p["id"],))
    related = []
    if p["category_id"]:
        related = product_query("category_id = ? AND id != ? AND stock > 0", (p["category_id"], p["id"]),
                                order="sold DESC, id DESC", limit=4)
    recent = recently_viewed(exclude=p["id"], limit=4)
    rv = [i for i in session.get("rv", []) if i != p["id"]]
    session["rv"] = ([p["id"]] + rv)[:8]
    colors = []
    for v in variants:
        if v["color"] not in colors:
            colors.append(v["color"])
    sizes = []
    for v in variants:
        if v["size"] not in sizes:
            sizes.append(v["size"])
    return render_template(
        "product.html", p=p, images=images, variants=[dict(v) for v in variants], colors=colors, sizes=sizes,
        reviews=reviews, related=related, recent=recent, dispatch=dispatch_info(),
        threshold=sint("low_stock_threshold", 5), prepaid_pct=sint("prepaid_discount_pct", 0),
    )


# ---------------------------------------------------------------------- cart
@bp.route("/cart")
def cart():
    lines = cart_lines()
    good = ok_lines(lines)
    totals = price_order(good, session.get("coupon"))
    if totals["coupon_error"] and session.get("coupon"):
        flash(totals["coupon_error"], "error")
        session.pop("coupon", None)
    in_cart = [l["pid"] for l in good]
    marks = ",".join("?" * len(in_cart)) if in_cart else "0"
    suggestions = product_query("stock > 0 AND id NOT IN (%s)" % marks, in_cart, order="sold DESC, id DESC", limit=4)
    return render_template("cart.html", lines=lines, good=good, totals=totals, suggestions=suggestions,
                           coupon=session.get("coupon", ""))


@bp.post("/cart/add")
def cart_add():
    vid = to_int(request.form.get("variant_id"), 0)
    qty = max(1, min(10, to_int(request.form.get("qty"), 1)))
    slug = request.form.get("slug", "")
    back = url_for("shop.product", slug=slug) if slug else url_for("shop.shop")
    v = db.q(
        "SELECT v.id, v.stock, p.is_active FROM variants v JOIN products p ON p.id = v.product_id WHERE v.id = ?",
        (vid,), one=True)
    if not v or not v["is_active"]:
        flash("Please choose a size first.", "error")
        return redirect(back)
    if v["stock"] <= 0:
        flash("Sorry, that size just sold out.", "error")
        return redirect(back)
    cart_data = session.get("cart", {})
    key = str(vid)
    cart_data[key] = min(int(cart_data.get(key, 0)) + qty, v["stock"], 10)
    session["cart"] = cart_data
    session.permanent = True
    if request.form.get("action") == "buy":
        return redirect(url_for("shop.checkout"))
    flash("Added to your cart.", "success")
    return redirect(url_for("shop.cart"))


@bp.post("/cart/update")
def cart_update():
    vid = str(to_int(request.form.get("variant_id"), 0))
    qty = to_int(request.form.get("qty"), 1)
    cart_data = session.get("cart", {})
    if vid in cart_data:
        if qty <= 0:
            cart_data.pop(vid)
        else:
            cart_data[vid] = min(qty, 10)
        session["cart"] = cart_data
    return redirect(url_for("shop.cart"))


@bp.post("/cart/coupon")
def cart_coupon():
    if request.form.get("remove"):
        session.pop("coupon", None)
        return redirect(request.form.get("next") or url_for("shop.cart"))
    code = request.form.get("code", "").strip().upper()[:30]
    good = ok_lines(cart_lines())
    subtotal = sum(l["line_total"] for l in good)
    coupon, err = utils.validate_coupon(code, subtotal)
    if err or not coupon:
        flash(err or "Enter a coupon code.", "error")
    else:
        session["coupon"] = coupon["code"]
        flash("Coupon %s applied." % coupon["code"], "success")
    nxt = request.form.get("next", "")
    return redirect(nxt if nxt in ("/cart", "/checkout") else url_for("shop.cart"))


# ------------------------------------------------------------------ checkout
def _validate_customer(form):
    errors = {}
    if len(form["name"]) < 2:
        errors["name"] = "Enter your full name."
    form["phone"] = normalize_phone(form["phone"])
    if not valid_phone(form["phone"]):
        errors["phone"] = "Enter a 10 digit mobile number."
    if form["email"] and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", form["email"]):
        errors["email"] = "That email address does not look right."
    if len(form["address"]) < 8:
        errors["address"] = "Enter your house number, street and area."
    if len(form["city"]) < 2:
        errors["city"] = "Enter your city."
    if form["state"] not in STATES:
        errors["state"] = "Choose your state."
    if not re.fullmatch(r"[1-9]\d{5}", form["pincode"]):
        errors["pincode"] = "Enter a 6 digit pincode."
    return errors


@bp.route("/checkout", methods=["GET", "POST"])
def checkout():
    orders.release_expired()
    lines = cart_lines()
    good = ok_lines(lines)
    if not good:
        if lines:
            flash("Sorry, the items in your cart just sold out. Please review your cart.", "error")
        else:
            flash("Your cart is empty. Add something you like first.", "error")
        return redirect(url_for("shop.cart"))
    if any(not l["available"] or l["wanted"] > l["qty"] for l in lines):
        flash("Some items in your cart changed in stock. Please review your cart before paying.", "error")
        return redirect(url_for("shop.cart"))

    coupon_code = session.get("coupon")
    rz = utils.razorpay_enabled()
    saved = session.get("customer", {})
    form = {k: (request.form.get(k, "") if request.method == "POST" else saved.get(k, "")).strip()
            for k in CUSTOMER_FIELDS}
    form["note"] = request.form.get("note", "").strip()[:300] if request.method == "POST" else ""
    method = request.form.get("payment_method") if request.method == "POST" else ("razorpay" if rz else "cod")
    errors = {}

    if request.method == "POST":
        errors = _validate_customer(form)
        if method not in ("cod", "razorpay") or (method == "razorpay" and not rz):
            errors["payment_method"] = "Choose how you would like to pay."
        if not errors:
            try:
                order_no = orders.create_order(form, good, coupon_code, method)
            except orders.OutOfStock as exc:
                flash("Sorry, %s just sold out or has less stock than in your cart. Please review your cart." % exc.name,
                      "error")
                return redirect(url_for("shop.cart"))
            session["customer"] = {k: form[k] for k in CUSTOMER_FIELDS}
            remember_order(order_no)
            session["cart"] = {}
            session.pop("coupon", None)
            if method == "cod":
                return redirect(url_for("shop.order_view", order_no=order_no, new=1))
            return redirect(url_for("shop.pay", order_no=order_no))
        flash("Please fix the highlighted fields.", "error")

    totals = {m: price_order(good, coupon_code, m) for m in ("cod", "razorpay")}
    return render_template("checkout.html", lines=good, form=form, errors=errors, method=method or "cod",
                           totals=totals, states=STATES, rz=rz, coupon=coupon_code or "",
                           coupon_error=totals["cod"]["coupon_error"])


# ------------------------------------------------------------------- payment
@bp.route("/pay/<order_no>")
def pay(order_no):
    orders.release_expired()
    order = owned_order(order_no)
    if order["payment_status"] == "paid" or order["status"] != "awaiting_payment":
        return redirect(url_for("shop.order_view", order_no=order["order_no"]))
    if not utils.razorpay_enabled():
        flash("Online payment is not available right now.", "error")
        return redirect(url_for("shop.order_view", order_no=order["order_no"]))
    rp_id = order["razorpay_order_id"]
    if not rp_id:
        try:
            rp_id = payments.create_order(order["total"] * 100, order["order_no"])["id"]
        except payments.PaymentError:
            flash("We could not start the payment. Please try again in a moment.", "error")
            return redirect(url_for("shop.order_view", order_no=order["order_no"]))
        db.ex("UPDATE orders SET razorpay_order_id = ? WHERE id = ?", (rp_id, order["id"]))
    return render_template("pay.html", order=order, rp_id=rp_id, key_id=current_app.config["RAZORPAY_KEY_ID"],
                           amount=order["total"] * 100)


@bp.post("/payment/verify")
def payment_verify():
    data = request.get_json(silent=True) or request.form
    rp_order = data.get("razorpay_order_id", "")
    rp_payment = data.get("razorpay_payment_id", "")
    sig = data.get("razorpay_signature", "")
    order = db.q("SELECT * FROM orders WHERE razorpay_order_id = ?", (rp_order,), one=True) if rp_order else None
    if not order or not payments.verify_signature(rp_order, rp_payment, sig):
        return jsonify(ok=False, message="We could not confirm that payment."), 400
    orders.mark_paid(order, rp_payment)
    remember_order(order["order_no"])
    return jsonify(ok=True, redirect=url_for("shop.order_view", order_no=order["order_no"], new=1))


@bp.post("/webhooks/razorpay")
def razorpay_webhook():
    raw = request.get_data()
    if not payments.verify_webhook(raw, request.headers.get("X-Razorpay-Signature", "")):
        return "", 400
    try:
        event = json.loads(raw)
    except ValueError:
        return "", 400
    if event.get("event") in ("payment.captured", "order.paid"):
        entity = event.get("payload", {}).get("payment", {}).get("entity", {})
        order = db.q("SELECT * FROM orders WHERE razorpay_order_id = ?", (entity.get("order_id", ""),), one=True)
        if order:
            orders.mark_paid(order, entity.get("id", ""))
    return "", 200


# -------------------------------------------------------------------- orders
STEPS = ["placed", "confirmed", "packed", "shipped", "delivered"]


@bp.route("/order/<order_no>")
def order_view(order_no):
    order = owned_order(order_no)
    items = db.q("SELECT * FROM order_items WHERE order_id = ?", (order["id"],))
    step = STEPS.index(order["status"]) if order["status"] in STEPS else -1
    reviewed = {r["product_id"] for r in db.q("SELECT product_id FROM reviews WHERE order_id = ?", (order["id"],))}
    return render_template("order.html", order=order, items=items, steps=STEPS, step=step,
                           new=bool(request.args.get("new")), reviewed=reviewed, dispatch=dispatch_info())


@bp.route("/track", methods=["GET", "POST"])
def track():
    if request.method == "POST":
        order_no = re.sub(r"\s", "", request.form.get("order_no", "")).upper()
        phone = normalize_phone(request.form.get("phone", ""))
        order = db.q("SELECT * FROM orders WHERE order_no = ?", (order_no,), one=True)
        if order and normalize_phone(order["phone"]) == phone:
            remember_order(order["order_no"])
            return redirect(url_for("shop.order_view", order_no=order["order_no"]))
        flash("We could not find an order with those details. Check the order number and the mobile number you used.",
              "error")
    return render_template("track.html")


@bp.post("/review")
def review():
    pid = to_int(request.form.get("product_id"), 0)
    order = db.q("SELECT * FROM orders WHERE order_no = ?", (request.form.get("order_no", "").upper(),), one=True)
    back = url_for("shop.order_view", order_no=order["order_no"]) if order else url_for("shop.home")
    if not order or order["order_no"] not in session.get("orders", []):
        abort(404)
    if order["status"] not in ("shipped", "delivered"):
        flash("You can review items once your order has shipped.", "error")
        return redirect(back)
    if not db.q("SELECT 1 FROM order_items WHERE order_id = ? AND product_id = ?", (order["id"], pid), one=True):
        abort(404)
    rating = to_int(request.form.get("rating"), 0)
    comment = request.form.get("comment", "").strip()[:600]
    if rating < 1 or rating > 5:
        flash("Please choose a star rating.", "error")
        return redirect(back)
    try:
        db.ex("INSERT INTO reviews(product_id, order_id, name, rating, comment) VALUES (?,?,?,?,?)",
              (pid, order["id"], order["name"].split()[0], rating, comment))
        flash("Thank you. Your review will appear after we check it.", "success")
    except Exception:
        flash("You have already reviewed this item.", "error")
    return redirect(back)


# --------------------------------------------------------------- static pages
@bp.route("/about")
def about():
    return render_template("info.html", page="about")


@bp.route("/shipping-returns")
def shipping_returns():
    return render_template("info.html", page="shipping")


@bp.route("/privacy")
def privacy():
    return render_template("info.html", page="privacy")


@bp.route("/contact")
def contact():
    return render_template("info.html", page="contact")


@bp.route("/media/<path:filename>")
def media(filename):
    return send_from_directory(current_app.config["UPLOAD_DIR"], filename, max_age=31536000)


@bp.route("/robots.txt")
def robots():
    base = current_app.config["SITE_URL"] or request.url_root.rstrip("/")
    body = "User-agent: *\nDisallow: /admin\nDisallow: /cart\nDisallow: /checkout\nDisallow: /order\n"
    body += "Sitemap: %s/sitemap.xml\n" % base
    return Response(body, mimetype="text/plain")


@bp.route("/sitemap.xml")
def sitemap():
    base = current_app.config["SITE_URL"] or request.url_root.rstrip("/")
    urls = [base + "/", base + "/shop"]
    urls += [base + "/shop?category=" + c["slug"] for c in utils.nav_categories()]
    urls += [base + "/product/" + r["slug"] for r in db.q("SELECT slug FROM products WHERE is_active = 1")]
    xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    xml += "".join("<url><loc>%s</loc></url>\n" % u.replace("&", "&amp;") for u in urls) + "</urlset>"
    return Response(xml, mimetype="application/xml")
