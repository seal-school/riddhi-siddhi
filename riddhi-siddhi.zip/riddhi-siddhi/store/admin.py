import csv
import io
import sqlite3
import time
from datetime import datetime, timedelta
from functools import wraps
from urllib.parse import quote

from flask import (Blueprint, Response, abort, flash, redirect, render_template, request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from . import db, orders, utils
from .utils import (IST, ORDER_STATUSES, PAYMENT_STATUSES, SALE_STATUSES, STATUS_LABEL, PAYMENT_LABEL, paginate,
                    product_count, product_query, sint, size_key, to_int)

bp = Blueprint("admin", __name__)

SALE_SQL = ",".join("'%s'" % s for s in SALE_STATUSES)
IST_DAY = "date(created_at, '+5 hours', '+30 minutes')"

SETTING_GROUPS = [
    ("Store details", [
        ("store_name", "Store name", "text", ""),
        ("tagline", "Tagline (shown in search results)", "text", ""),
        ("hero_title", "Homepage headline", "text", ""),
        ("hero_text", "Homepage sub text", "text", ""),
        ("announcement", "Top bar message", "text", "Leave empty to show free shipping and online payment offers automatically."),
        ("about_text", "About us text", "textarea", ""),
    ]),
    ("Contact and business", [
        ("phone", "Phone number", "text", "Shown on the contact page and invoices."),
        ("whatsapp", "WhatsApp number", "text", "10 digit number. Adds a WhatsApp chat button to every page."),
        ("email", "Email", "text", ""),
        ("address", "Shop address", "textarea", "Shown in the footer and on invoices."),
        ("gstin", "GSTIN (if registered)", "text", "Shown on invoices."),
    ]),
    ("Pricing and delivery", [
        ("shipping_fee", "Shipping fee (₹)", "number", ""),
        ("free_shipping_above", "Free shipping above (₹)", "number", "Set to 0 to make shipping always free."),
        ("prepaid_discount_pct", "Extra discount for paying online (%)", "number", "Encourages online payment, which means fewer returns and no cash handling."),
        ("cod_fee", "Cash on delivery fee (₹)", "number", "Set to 0 for no fee."),
        ("delivery_estimate", "Delivery time shown to customers", "text", ""),
        ("dispatch_cutoff_hour", "Same day dispatch cut-off (hour, 24h IST)", "number", "For example 16 for 4 PM. Set 0 to hide the countdown."),
        ("return_days", "Return window (days)", "number", ""),
        ("low_stock_threshold", "Low stock warning at or below", "number", "Customers see 'Only N left' at this level. Admin sees it on the dashboard."),
    ]),
]
SETTING_KEYS = [k for _, fields in SETTING_GROUPS for k, *_ in fields]
NUMERIC_KEYS = {"shipping_fee", "free_shipping_above", "prepaid_discount_pct", "cod_fee",
                "dispatch_cutoff_hour", "return_days", "low_stock_threshold"}

_attempts = {}


# --------------------------------------------------------------------- auth
def admin_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if not session.get("admin_id"):
            return redirect(url_for("admin.login", next=request.path))
        return view(*args, **kwargs)
    return wrapper


def _throttled(ip):
    now = time.time()
    recent = [t for t in _attempts.get(ip, []) if now - t < 600]
    _attempts[ip] = recent
    return len(recent) >= 8


@bp.route("/login", methods=["GET", "POST"])
def login():
    if session.get("admin_id"):
        return redirect(url_for("admin.dashboard"))
    if request.method == "POST":
        ip = request.remote_addr or "?"
        if _throttled(ip):
            flash("Too many attempts. Please wait ten minutes and try again.", "error")
            return render_template("admin/login.html"), 429
        user = db.q("SELECT * FROM admins WHERE username = ?", (request.form.get("username", "").strip(),), one=True)
        hashed = user["password_hash"] if user else generate_password_hash("not-a-real-password")
        if check_password_hash(hashed, request.form.get("password", "")) and user:
            session.clear()
            session["admin_id"] = user["id"]
            session.permanent = True
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/admin") and not nxt.startswith("//") else url_for("admin.dashboard"))
        _attempts.setdefault(ip, []).append(time.time())
        flash("Wrong username or password.", "error")
    return render_template("admin/login.html")


@bp.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("admin.login"))


@bp.context_processor
def admin_nav_counts():
    if not session.get("admin_id"):
        return {}
    row = db.q("SELECT (SELECT COUNT(*) FROM orders WHERE status = 'placed') AS new_orders, "
               "(SELECT COUNT(*) FROM orders WHERE status = 'needs_review') AS review_orders, "
               "(SELECT COUNT(*) FROM reviews WHERE approved = 0) AS pending_reviews", one=True)
    return {"nav_counts": row}


# ---------------------------------------------------------------- dashboard
@bp.route("/")
@admin_required
def dashboard():
    orders.release_expired()
    thr = sint("low_stock_threshold", 5)
    today = db.q(
        "SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS rev FROM orders WHERE status IN (%s) "
        "AND %s = date('now','+5 hours','+30 minutes')" % (SALE_SQL, IST_DAY), one=True)
    month = db.q(
        "SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS rev FROM orders WHERE status IN (%s) "
        "AND created_at >= datetime('now','-30 day')" % SALE_SQL, one=True)
    rows = {r["d"]: r for r in db.q(
        "SELECT %s AS d, COUNT(*) AS n, COALESCE(SUM(total),0) AS rev FROM orders WHERE status IN (%s) "
        "AND created_at >= datetime('now','-8 day') GROUP BY d" % (IST_DAY, SALE_SQL))}
    days, base = [], datetime.now(IST).date()
    for i in range(6, -1, -1):
        d = base - timedelta(days=i)
        r = rows.get(d.isoformat())
        days.append(dict(label=d.strftime("%a"), rev=r["rev"] if r else 0, n=r["n"] if r else 0))
    peak = max([d["rev"] for d in days] + [1])
    counts = {r["status"]: r["n"] for r in db.q("SELECT status, COUNT(*) AS n FROM orders GROUP BY status")}
    low = db.q(
        """SELECT v.id, v.size, v.color, v.stock, p.id AS pid, p.name FROM variants v
           JOIN products p ON p.id = v.product_id WHERE p.is_active = 1 AND v.stock <= ?
           ORDER BY v.stock, p.name LIMIT 10""", (thr,))
    low_total = db.q("SELECT COUNT(*) AS n FROM variants v JOIN products p ON p.id = v.product_id "
                     "WHERE p.is_active = 1 AND v.stock <= ?", (thr,), one=True)["n"]
    top = db.q(
        """SELECT oi.name, SUM(oi.qty) AS qty, SUM(oi.qty * oi.price) AS rev FROM order_items oi
           JOIN orders o ON o.id = oi.order_id WHERE o.status IN (%s) AND o.created_at >= datetime('now','-30 day')
           GROUP BY oi.product_id, oi.name ORDER BY qty DESC LIMIT 5""" % SALE_SQL)
    recent = db.q("SELECT * FROM orders WHERE status != 'awaiting_payment' ORDER BY id DESC LIMIT 8")
    stats = db.q("SELECT (SELECT COUNT(*) FROM products) AS products, "
                 "(SELECT COALESCE(SUM(stock),0) FROM variants) AS units, "
                 "(SELECT COUNT(*) FROM reviews WHERE approved = 0) AS reviews", one=True)
    return render_template("admin/dashboard.html", today=today, month=month, days=days, peak=peak, counts=counts,
                           low=low, low_total=low_total, top=top, recent=recent, thr=thr, stats=stats)


# ----------------------------------------------------------------- products
def _admin_product_filters():
    q = request.args.get("q", "").strip()[:80]
    cat = to_int(request.args.get("category"), 0)
    status = request.args.get("status", "")
    thr = sint("low_stock_threshold", 5)
    where, args = ["1=1"], []
    if q:
        where.append("(name LIKE ? OR id IN (SELECT product_id FROM variants WHERE sku LIKE ?))")
        args += ["%" + q + "%", "%" + q + "%"]
    if cat:
        where.append("category_id = ?")
        args.append(cat)
    if status == "active":
        where.append("is_active = 1")
    elif status == "hidden":
        where.append("is_active = 0")
    elif status == "low":
        where.append("stock > 0 AND stock <= ?")
        args.append(thr)
    elif status == "out":
        where.append("stock <= 0")
    return " AND ".join(where), args, q, cat, status


@bp.route("/products")
@admin_required
def products():
    clause, args, q, cat, status = _admin_product_filters()
    page = max(1, to_int(request.args.get("page"), 1))
    total = product_count(clause, args, active_only=False)
    pg = paginate(total, page, 30)
    rows = product_query(clause, args, order="id DESC", limit=30, offset=(pg["page"] - 1) * 30, active_only=False)
    cats = db.q("SELECT * FROM categories ORDER BY sort, name")
    keep = {k: v for k, v in request.args.items() if k != "page" and v}
    return render_template("admin/products.html", products=rows, pg=pg, q=q, cat=cat, status=status, cats=cats,
                           keep=keep, thr=sint("low_stock_threshold", 5))


def _parse_variants(form):
    rows, errors, seen = [], [], set()
    ids, sizes = form.getlist("v_id"), form.getlist("v_size")
    colors, skus, stocks = form.getlist("v_color"), form.getlist("v_sku"), form.getlist("v_stock")
    for i, raw_size in enumerate(sizes):
        size = raw_size.strip()[:20]
        if not size:
            continue
        color = (colors[i] if i < len(colors) else "").strip()[:30]
        key = (size.lower(), color.lower())
        if key in seen:
            errors.append("Size %s%s is listed twice." % (size, (" in " + color) if color else ""))
            continue
        seen.add(key)
        rows.append(dict(id=to_int(ids[i] if i < len(ids) else 0), size=size, color=color,
                         sku=(skus[i] if i < len(skus) else "").strip()[:40],
                         stock=max(0, to_int(stocks[i] if i < len(stocks) else 0))))
    return rows, errors


@bp.route("/products/new", methods=["GET", "POST"])
@bp.route("/products/<int:pid>/edit", methods=["GET", "POST"])
@admin_required
def product_form(pid=None):
    product = db.q("SELECT * FROM products WHERE id = ?", (pid,), one=True) if pid else None
    if pid and not product:
        abort(404)
    cats = db.q("SELECT * FROM categories ORDER BY sort, name")
    images = db.q("SELECT * FROM images WHERE product_id = ? ORDER BY sort, id", (pid,)) if pid else []
    if request.method == "GET":
        variants = sorted(db.q("SELECT * FROM variants WHERE product_id = ?", (pid,)) if pid else [],
                          key=lambda v: (size_key(v["size"]), v["color"].lower()))
        return render_template("admin/product_form.html", p=product, variants=variants, images=images, cats=cats)

    f = request.form
    name = f.get("name", "").strip()[:140]
    price, mrp = to_int(f.get("price"), 0), to_int(f.get("mrp"), 0)
    variants, errors = _parse_variants(f)
    if not name:
        errors.append("Enter a product name.")
    if price <= 0:
        errors.append("Enter the selling price.")
    if mrp and mrp < price:
        errors.append("The MRP cannot be lower than the selling price.")
    if not variants:
        errors.append("Add at least one size with its stock.")
    new_files = [x for x in request.files.getlist("images") if x and x.filename]
    if len(images) + len(new_files) - len(f.getlist("del_img")) > 8:
        errors.append("A product can have up to 8 photos.")
    posted = dict(id=pid, name=name, category_id=to_int(f.get("category_id"), 0) or None, price=price,
                  mrp=mrp or price, description=f.get("description", "").strip(),
                  fabric_care=f.get("fabric_care", "").strip(), is_active=1 if f.get("is_active") else 0,
                  is_featured=1 if f.get("is_featured") else 0)
    if errors:
        for e in errors:
            flash(e, "error")
        return render_template("admin/product_form.html", p=posted, variants=variants, images=images, cats=cats), 400

    conn = db.get_db()
    try:
        if pid:
            conn.execute(
                "UPDATE products SET name=?, category_id=?, price=?, mrp=?, description=?, fabric_care=?, "
                "is_active=?, is_featured=? WHERE id=?",
                (name, posted["category_id"], price, posted["mrp"], posted["description"], posted["fabric_care"],
                 posted["is_active"], posted["is_featured"], pid))
        else:
            cur = conn.execute(
                "INSERT INTO products(name, slug, category_id, price, mrp, description, fabric_care, is_active, is_featured) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (name, utils.unique_slug("products", name), posted["category_id"], price, posted["mrp"],
                 posted["description"], posted["fabric_care"], posted["is_active"], posted["is_featured"]))
            pid = cur.lastrowid

        existing = {v["id"]: v for v in conn.execute("SELECT * FROM variants WHERE product_id = ?", (pid,)).fetchall()}
        kept = set()
        # free up unique (size, color) keys first so rows can be renamed or swapped safely
        for v in variants:
            if v["id"] in existing:
                conn.execute("UPDATE variants SET size = '~' || id, color = '~' WHERE id = ?", (v["id"],))
        for v in variants:
            label = orders.variant_label(name, v["size"], v["color"])
            if v["id"] in existing:
                kept.add(v["id"])
                old = existing[v["id"]]["stock"]
                conn.execute("UPDATE variants SET size=?, color=?, sku=?, stock=? WHERE id=?",
                             (v["size"], v["color"], v["sku"], v["stock"], v["id"]))
                if v["stock"] != old:
                    orders.log_stock(v["id"], label, v["stock"] - old, "Edited in product form")
            else:
                cur = conn.execute("INSERT INTO variants(product_id, size, color, sku, stock) VALUES (?,?,?,?,?)",
                                   (pid, v["size"], v["color"], v["sku"], v["stock"]))
                if v["stock"]:
                    orders.log_stock(cur.lastrowid, label, v["stock"], "New variant")
        for vid, old in existing.items():
            if vid not in kept:
                conn.execute("DELETE FROM variants WHERE id = ?", (vid,))
                if old["stock"]:
                    orders.log_stock(vid, orders.variant_label(name, old["size"], old["color"]), -old["stock"],
                                     "Variant removed")

        removed = []
        for img_id in f.getlist("del_img"):
            row = conn.execute("SELECT filename FROM images WHERE id = ? AND product_id = ?",
                               (to_int(img_id), pid)).fetchone()
            if row:
                removed.append(row["filename"])
                conn.execute("DELETE FROM images WHERE id = ?", (to_int(img_id),))
        main = to_int(f.get("main_img"), 0)
        if main:
            conn.execute("UPDATE images SET sort = sort + 1 WHERE product_id = ?", (pid,))
            conn.execute("UPDATE images SET sort = 0 WHERE id = ? AND product_id = ?", (main, pid))
        next_sort = (conn.execute("SELECT COALESCE(MAX(sort), 0) + 1 FROM images WHERE product_id = ?", (pid,)).fetchone()[0])
        upload_errors = []
        for file in new_files:
            try:
                fname = utils.save_image(file)
            except ValueError as exc:
                upload_errors.append("%s: %s" % (file.filename, exc))
                continue
            conn.execute("INSERT INTO images(product_id, filename, sort) VALUES (?,?,?)", (pid, fname, next_sort))
            next_sort += 1
        conn.commit()
    except sqlite3.IntegrityError:
        conn.rollback()
        flash("Could not save. Check that each size and colour combination appears only once.", "error")
        return render_template("admin/product_form.html", p=posted, variants=variants, images=images, cats=cats), 400
    for fname in removed:
        utils.delete_image_file(fname)
    for msg in upload_errors:
        flash(msg, "error")
    flash("Product saved.", "success")
    return redirect(url_for("admin.product_form", pid=pid))


@bp.post("/products/<int:pid>/toggle")
@admin_required
def product_toggle(pid):
    db.ex("UPDATE products SET is_active = 1 - is_active WHERE id = ?", (pid,))
    return redirect(request.form.get("next") if (request.form.get("next") or "").startswith("/admin") else url_for("admin.products"))


@bp.post("/products/<int:pid>/duplicate")
@admin_required
def product_duplicate(pid):
    p = db.q("SELECT * FROM products WHERE id = ?", (pid,), one=True)
    if not p:
        abort(404)
    name = p["name"] + " (copy)"
    conn = db.get_db()
    cur = conn.execute(
        "INSERT INTO products(name, slug, category_id, price, mrp, description, fabric_care, is_active, is_featured) "
        "VALUES (?,?,?,?,?,?,?,0,0)",
        (name, utils.unique_slug("products", name), p["category_id"], p["price"], p["mrp"], p["description"], p["fabric_care"]))
    new_id = cur.lastrowid
    for v in conn.execute("SELECT * FROM variants WHERE product_id = ?", (pid,)).fetchall():
        conn.execute("INSERT INTO variants(product_id, size, color, sku, stock) VALUES (?,?,?,?,?)",
                     (new_id, v["size"], v["color"], "", 0))
    conn.commit()
    flash("Copied. The copy is hidden with zero stock until you edit it.", "success")
    return redirect(url_for("admin.product_form", pid=new_id))


@bp.post("/products/<int:pid>/delete")
@admin_required
def product_delete(pid):
    files = [r["filename"] for r in db.q("SELECT filename FROM images WHERE product_id = ?", (pid,))]
    db.ex("DELETE FROM products WHERE id = ?", (pid,))
    for fname in files:
        utils.delete_image_file(fname)
    flash("Product deleted. Past orders keep their details.", "success")
    return redirect(url_for("admin.products"))


# ---------------------------------------------------------------- inventory
@bp.route("/inventory", methods=["GET", "POST"])
@admin_required
def inventory():
    if request.method == "POST":
        conn = db.get_db()
        changed = 0
        for key, raw in request.form.items():
            if not key.startswith("stock_"):
                continue
            vid, new = to_int(key[6:]), max(0, to_int(raw, -1))
            if raw.strip() == "" or new < 0:
                continue
            row = conn.execute("SELECT v.stock, v.size, v.color, p.name FROM variants v JOIN products p "
                               "ON p.id = v.product_id WHERE v.id = ?", (vid,)).fetchone()
            if row and row["stock"] != new:
                conn.execute("UPDATE variants SET stock = ? WHERE id = ?", (new, vid))
                orders.log_stock(vid, orders.variant_label(row["name"], row["size"], row["color"]),
                                 new - row["stock"], request.form.get("reason", "").strip()[:80] or "Stock count")
                changed += 1
        conn.commit()
        flash("Updated stock for %d item%s." % (changed, "" if changed == 1 else "s") if changed else "No changes to save.",
              "success" if changed else "error")
        return redirect(request.form.get("back") if (request.form.get("back") or "").startswith("/admin/inventory") else url_for("admin.inventory"))

    q = request.args.get("q", "").strip()[:80]
    status = request.args.get("status", "")
    page = max(1, to_int(request.args.get("page"), 1))
    thr = sint("low_stock_threshold", 5)
    where, args = ["1=1"], []
    if q:
        where.append("(p.name LIKE ? OR v.sku LIKE ? OR v.size LIKE ? OR v.color LIKE ?)")
        args += ["%" + q + "%"] * 4
    if status == "low":
        where.append("v.stock > 0 AND v.stock <= ?")
        args.append(thr)
    elif status == "out":
        where.append("v.stock = 0")
    clause = " AND ".join(where)
    total = db.q("SELECT COUNT(*) AS n FROM variants v JOIN products p ON p.id = v.product_id WHERE " + clause, args, one=True)["n"]
    pg = paginate(total, page, 50)
    rows = db.q(
        "SELECT v.id, v.size, v.color, v.sku, v.stock, p.id AS pid, p.name, p.is_active FROM variants v "
        "JOIN products p ON p.id = v.product_id WHERE %s ORDER BY p.name, v.id LIMIT 50 OFFSET ?" % clause,
        args + [(pg["page"] - 1) * 50])
    rows = sorted(rows, key=lambda r: (r["name"].lower(), size_key(r["size"]), r["color"].lower()))
    log = db.q("SELECT * FROM stock_log ORDER BY id DESC LIMIT 12")
    totals = db.q("SELECT COALESCE(SUM(stock),0) AS units, COUNT(*) AS skus, "
                  "COALESCE(SUM(CASE WHEN stock = 0 THEN 1 ELSE 0 END),0) AS out, "
                  "COALESCE(SUM(CASE WHEN stock > 0 AND stock <= ? THEN 1 ELSE 0 END),0) AS low FROM variants", (thr,), one=True)
    keep = {k: v for k, v in request.args.items() if k != "page" and v}
    return render_template("admin/inventory.html", rows=rows, pg=pg, q=q, status=status, log=log, totals=totals,
                           thr=thr, keep=keep, back=request.full_path.rstrip("?"))


# ------------------------------------------------------------------- orders
def _order_filters():
    q = request.args.get("q", "").strip()[:60]
    status = request.args.get("status", "")
    pay = request.args.get("payment", "")
    start, end = request.args.get("from", ""), request.args.get("to", "")
    where, args = ["1=1"], []
    if status in STATUS_LABEL:
        where.append("status = ?")
        args.append(status)
    elif not status:
        where.append("status != 'awaiting_payment'")
    if pay in ("cod", "razorpay"):
        where.append("payment_method = ?")
        args.append(pay)
    if q:
        where.append("(order_no LIKE ? OR name LIKE ? OR phone LIKE ?)")
        args += ["%" + q + "%"] * 3
    if start:
        where.append("%s >= ?" % IST_DAY)
        args.append(start)
    if end:
        where.append("%s <= ?" % IST_DAY)
        args.append(end)
    return " AND ".join(where), args, q, status, pay, start, end


@bp.route("/orders")
@admin_required
def orders_list():
    orders.release_expired()
    clause, args, q, status, pay, start, end = _order_filters()
    page = max(1, to_int(request.args.get("page"), 1))
    total = db.q("SELECT COUNT(*) AS n FROM orders WHERE " + clause, args, one=True)["n"]
    pg = paginate(total, page, 25)
    rows = db.q("SELECT o.*, (SELECT SUM(qty) FROM order_items WHERE order_id = o.id) AS units FROM orders o "
                "WHERE %s ORDER BY id DESC LIMIT 25 OFFSET ?" % clause, args + [(pg["page"] - 1) * 25])
    counts = {r["status"]: r["n"] for r in db.q("SELECT status, COUNT(*) AS n FROM orders GROUP BY status")}
    keep = {k: v for k, v in request.args.items() if k != "page" and v}
    return render_template("admin/orders.html", orders=rows, pg=pg, q=q, status=status, pay=pay, start=start,
                           end=end, counts=counts, keep=keep)


def _order_or_404(oid):
    o = db.q("SELECT * FROM orders WHERE id = ?", (oid,), one=True)
    if not o:
        abort(404)
    return o


def _wa_link(order, text):
    phone = "91" + utils.normalize_phone(order["phone"])
    return "https://wa.me/%s?text=%s" % (phone, quote(text))


@bp.route("/orders/<int:oid>")
@admin_required
def order_detail(oid):
    o = _order_or_404(oid)
    items = db.q("SELECT * FROM order_items WHERE order_id = ?", (oid,))
    events = db.q("SELECT * FROM order_events WHERE order_id = ? ORDER BY id DESC", (oid,))
    store = utils.get_settings()["store_name"]
    first = o["name"].split()[0]
    messages = {
        "confirm": "Hi %s, thank you for ordering from %s. Your order %s of %s is confirmed." % (first, store, o["order_no"], utils.inr(o["total"])),
        "ship": "Hi %s, your %s order %s has been shipped%s. %s" % (
            first, store, o["order_no"], (" via %s" % o["courier"]) if o["courier"] else "",
            ("Tracking number: %s" % o["tracking_no"]) if o["tracking_no"] else ""),
        "cod": "Hi %s, this is %s about your cash on delivery order %s of %s. Please confirm that we can ship it to %s."
               % (first, store, o["order_no"], utils.inr(o["total"]), o["city"]),
    }
    wa = {k: _wa_link(o, v.strip()) for k, v in messages.items()}
    return render_template("admin/order_detail.html", o=o, items=items, events=events, wa=wa,
                           payment_statuses=PAYMENT_STATUSES)


@bp.post("/orders/<int:oid>/update")
@admin_required
def order_update(oid):
    o = _order_or_404(oid)
    f = request.form
    new = f.get("status", o["status"])
    if new not in STATUS_LABEL:
        abort(400)
    courier, tracking = f.get("courier", "").strip()[:60], f.get("tracking_no", "").strip()[:80]
    note = f.get("admin_note", "").strip()[:1000]
    conn = db.get_db()
    if new != o["status"]:
        if o["status"] in ("cancelled", "returned"):
            flash("A %s order cannot be reopened. Ask the customer to place a new order." % STATUS_LABEL[o["status"]].lower(), "error")
            return redirect(url_for("admin.order_detail", oid=oid))
        try:
            if new in ("cancelled", "returned"):
                orders.restore_stock(oid, "Order " + new)
                if o["payment_status"] == "paid" and o["payment_method"] == "razorpay":
                    conn.execute("UPDATE orders SET payment_status = 'refund_due' WHERE id = ?", (oid,))
                    orders.log_event(oid, "Refund the customer from the Razorpay dashboard, then mark this order as refunded.")
            elif o["stock_restored"] and new not in ("awaiting_payment",):
                orders.re_reserve(oid)
            if new == "delivered" and o["payment_method"] == "cod" and o["payment_status"] == "cod_pending":
                conn.execute("UPDATE orders SET payment_status = 'paid', paid_at = datetime('now') WHERE id = ?", (oid,))
                orders.log_event(oid, "Cash collected on delivery.")
        except orders.OutOfStock as exc:
            conn.rollback()
            flash("Not enough stock of %s to move this order forward. Add stock first." % exc.name, "error")
            return redirect(url_for("admin.order_detail", oid=oid))
        orders.log_event(oid, "Status changed from %s to %s." % (STATUS_LABEL[o["status"]], STATUS_LABEL[new]))
    if (courier, tracking) != (o["courier"], o["tracking_no"]):
        orders.log_event(oid, "Shipping details updated: %s %s" % (courier or "no courier", tracking))
    conn.execute("UPDATE orders SET status=?, courier=?, tracking_no=?, admin_note=?, updated_at=datetime('now') WHERE id=?",
                 (new, courier, tracking, note, oid))
    conn.commit()
    flash("Order updated.", "success")
    return redirect(url_for("admin.order_detail", oid=oid))


@bp.post("/orders/<int:oid>/payment")
@admin_required
def order_payment(oid):
    o = _order_or_404(oid)
    new = request.form.get("payment_status", "")
    if new not in PAYMENT_LABEL:
        abort(400)
    if new != o["payment_status"]:
        conn = db.get_db()
        conn.execute("UPDATE orders SET payment_status = ?, paid_at = CASE WHEN ? = 'paid' THEN datetime('now') ELSE paid_at END, "
                     "updated_at = datetime('now') WHERE id = ?", (new, new, oid))
        orders.log_event(oid, "Payment status changed to %s." % PAYMENT_LABEL[new])
        conn.commit()
        flash("Payment status updated.", "success")
    return redirect(url_for("admin.order_detail", oid=oid))


@bp.route("/orders/<int:oid>/invoice")
@admin_required
def order_invoice(oid):
    o = _order_or_404(oid)
    items = db.q("SELECT * FROM order_items WHERE order_id = ?", (oid,))
    return render_template("admin/invoice.html", o=o, items=items)


def _csv_response(name, header, rows):
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(header)
    for row in rows:
        writer.writerow([("'" + c) if isinstance(c, str) and c[:1] in ("=", "+", "-", "@") else c for c in row])
    return Response("\ufeff" + buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=%s" % name})


@bp.route("/export/orders.csv")
@admin_required
def export_orders():
    clause, args, *_ = _order_filters()
    rows = db.q("SELECT o.*, (SELECT GROUP_CONCAT(name || ' ' || size || CASE WHEN color != '' THEN '/' || color ELSE '' END || ' x' || qty, '; ') "
                "FROM order_items WHERE order_id = o.id) AS items FROM orders o WHERE %s ORDER BY id DESC" % clause, args)
    return _csv_response(
        "orders.csv",
        ["Order", "Date (IST)", "Name", "Phone", "Email", "Address", "City", "State", "Pincode", "Items", "Subtotal",
         "Discount", "Online payment discount", "Shipping", "COD fee", "Total", "Payment", "Payment status", "Status",
         "Courier", "Tracking"],
        [[r["order_no"], utils.ist(r["created_at"]), r["name"], r["phone"], r["email"], r["address"], r["city"],
          r["state"], r["pincode"], r["items"], r["subtotal"], r["discount"], r["prepaid_discount"], r["shipping"],
          r["cod_fee"], r["total"], "COD" if r["payment_method"] == "cod" else "Online",
          PAYMENT_LABEL.get(r["payment_status"], r["payment_status"]), STATUS_LABEL.get(r["status"], r["status"]),
          r["courier"], r["tracking_no"]] for r in rows])


# --------------------------------------------------------------- CSV import
IMPORT_HEADER = ["name", "category", "price", "mrp", "size", "color", "stock", "sku", "description", "fabric_care"]


@bp.route("/export/products.csv")
@admin_required
def export_products():
    rows = db.q("""SELECT p.name, c.name AS category, p.price, p.mrp, v.size, v.color, v.stock, v.sku, p.description, p.fabric_care
                   FROM variants v JOIN products p ON p.id = v.product_id LEFT JOIN categories c ON c.id = p.category_id
                   ORDER BY p.name, v.id""")
    return _csv_response("products-and-stock.csv", IMPORT_HEADER, [[r[h] for h in IMPORT_HEADER] for r in rows])


@bp.route("/import/sample.csv")
@admin_required
def import_sample():
    sample = [
        ["Cotton Straight Kurti", "Women", 799, 1299, "M", "Indigo", 20, "KRT-IND-M", "Soft everyday cotton kurti.", "Machine wash cold"],
        ["Cotton Straight Kurti", "Women", 799, 1299, "L", "Indigo", 18, "KRT-IND-L", "", ""],
        ["Classic Oxford Shirt", "Men", 999, 1499, "40", "White", 12, "SHT-WHT-40", "Full sleeve cotton shirt.", ""],
    ]
    return _csv_response("import-sample.csv", IMPORT_HEADER, sample)


@bp.route("/import", methods=["GET", "POST"])
@admin_required
def import_csv():
    report = None
    if request.method == "POST":
        file = request.files.get("file")
        mode = request.form.get("mode", "set")
        if not file or not file.filename.lower().endswith(".csv"):
            flash("Choose a .csv file. In Excel use Save As, then CSV UTF-8.", "error")
            return render_template("admin/import.html", report=None, header=IMPORT_HEADER)
        try:
            text = file.read().decode("utf-8-sig")
        except UnicodeDecodeError:
            flash("That file is not UTF-8. In Excel choose Save As, then CSV UTF-8.", "error")
            return render_template("admin/import.html", report=None, header=IMPORT_HEADER)
        report = _run_import(text, mode)
    return render_template("admin/import.html", report=report, header=IMPORT_HEADER)


def _run_import(text, mode):
    conn = db.get_db()
    reader = csv.DictReader(io.StringIO(text))
    reader.fieldnames = [(h or "").strip().lower() for h in (reader.fieldnames or [])]
    report = dict(products_new=0, products_updated=0, variants_new=0, variants_updated=0, errors=[], rows=0)
    missing = [h for h in ("name", "price", "size", "stock") if h not in reader.fieldnames]
    if missing:
        report["errors"].append("Missing column(s): %s. Download the sample file to see the layout." % ", ".join(missing))
        return report
    cats = {c["name"].lower(): c["id"] for c in conn.execute("SELECT id, name FROM categories").fetchall()}
    prods = {p["name"].lower(): p["id"] for p in conn.execute("SELECT id, name FROM products").fetchall()}
    touched = set()
    for n, row in enumerate(reader, start=2):
        row = {k: (v or "").strip() for k, v in row.items() if k}
        if not any(row.values()):
            continue
        report["rows"] += 1
        name, size = row.get("name", ""), row.get("size", "")[:20]
        price, mrp, stock = to_int(row.get("price"), 0), to_int(row.get("mrp"), 0), to_int(row.get("stock"), -1)
        if not name or not size or price <= 0 or stock < 0:
            report["errors"].append("Row %d skipped: needs name, size, a price above 0 and a stock number." % n)
            continue
        mrp = max(mrp, price)
        cat_id = None
        if row.get("category"):
            key = row["category"].lower()
            if key not in cats:
                cur = conn.execute("INSERT INTO categories(name, slug, sort) VALUES (?,?,?)",
                                   (row["category"][:60], utils.unique_slug("categories", row["category"]), len(cats)))
                cats[key] = cur.lastrowid
            cat_id = cats[key]
        pid = prods.get(name.lower())
        if pid:
            if pid not in touched:
                report["products_updated"] += 1
            conn.execute("UPDATE products SET price = ?, mrp = ?, category_id = COALESCE(?, category_id), "
                         "description = CASE WHEN ? != '' THEN ? ELSE description END, "
                         "fabric_care = CASE WHEN ? != '' THEN ? ELSE fabric_care END WHERE id = ?",
                         (price, mrp, cat_id, row.get("description", ""), row.get("description", ""),
                          row.get("fabric_care", ""), row.get("fabric_care", ""), pid))
        else:
            cur = conn.execute(
                "INSERT INTO products(name, slug, category_id, price, mrp, description, fabric_care, is_active) VALUES (?,?,?,?,?,?,?,1)",
                (name[:140], utils.unique_slug("products", name), cat_id, price, mrp, row.get("description", ""),
                 row.get("fabric_care", "")))
            pid = cur.lastrowid
            prods[name.lower()] = pid
            report["products_new"] += 1
        touched.add(pid)
        color = row.get("color", "")[:30]
        var = conn.execute("SELECT id, stock FROM variants WHERE product_id = ? AND lower(size) = lower(?) AND lower(color) = lower(?)",
                           (pid, size, color)).fetchone()
        label = orders.variant_label(name, size, color)
        if var:
            new_stock = var["stock"] + stock if mode == "add" else stock
            conn.execute("UPDATE variants SET stock = ?, sku = CASE WHEN ? != '' THEN ? ELSE sku END WHERE id = ?",
                         (new_stock, row.get("sku", ""), row.get("sku", "")[:40], var["id"]))
            if new_stock != var["stock"]:
                orders.log_stock(var["id"], label, new_stock - var["stock"], "CSV import")
            report["variants_updated"] += 1
        else:
            cur = conn.execute("INSERT INTO variants(product_id, size, color, sku, stock) VALUES (?,?,?,?,?)",
                               (pid, size, color, row.get("sku", "")[:40], stock))
            if stock:
                orders.log_stock(cur.lastrowid, label, stock, "CSV import")
            report["variants_new"] += 1
    conn.commit()
    return report


# --------------------------------------------------- categories and coupons
@bp.route("/categories", methods=["GET", "POST"])
@admin_required
def categories():
    if request.method == "POST":
        action, f = request.form.get("action"), request.form
        if action == "add":
            name = f.get("name", "").strip()[:60]
            if name:
                db.ex("INSERT INTO categories(name, slug, sort) VALUES (?,?,?)",
                      (name, utils.unique_slug("categories", name), to_int(f.get("sort"), 0)))
                flash("Category added.", "success")
        elif action == "save":
            cid, name = to_int(f.get("id")), f.get("name", "").strip()[:60]
            if name:
                db.ex("UPDATE categories SET name = ?, sort = ? WHERE id = ?", (name, to_int(f.get("sort"), 0), cid))
                flash("Category saved.", "success")
        elif action == "delete":
            db.ex("DELETE FROM categories WHERE id = ?", (to_int(f.get("id")),))
            flash("Category deleted. Its products are now uncategorised.", "success")
        return redirect(url_for("admin.categories"))
    rows = db.q("SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id = c.id) AS n FROM categories c ORDER BY sort, name")
    return render_template("admin/categories.html", cats=rows)


@bp.route("/coupons", methods=["GET", "POST"])
@admin_required
def coupons():
    if request.method == "POST":
        action, f = request.form.get("action"), request.form
        if action == "add":
            code = "".join(ch for ch in f.get("code", "").upper() if ch.isalnum())[:20]
            kind = "flat" if f.get("kind") == "flat" else "percent"
            value = to_int(f.get("value"), 0)
            if not code or value <= 0 or (kind == "percent" and value > 90):
                flash("Enter a code and a value (percent discounts can be 1 to 90).", "error")
            else:
                try:
                    db.ex("INSERT INTO coupons(code, kind, value, min_order, max_discount, uses_limit, expires) VALUES (?,?,?,?,?,?,?)",
                          (code, kind, value, to_int(f.get("min_order")), to_int(f.get("max_discount")),
                           to_int(f.get("uses_limit")), f.get("expires") or None))
                    flash("Coupon %s created." % code, "success")
                except sqlite3.IntegrityError:
                    flash("That code already exists.", "error")
        elif action == "toggle":
            db.ex("UPDATE coupons SET active = 1 - active WHERE id = ?", (to_int(f.get("id")),))
        elif action == "delete":
            db.ex("DELETE FROM coupons WHERE id = ?", (to_int(f.get("id")),))
            flash("Coupon deleted.", "success")
        return redirect(url_for("admin.coupons"))
    return render_template("admin/coupons.html", coupons=db.q("SELECT * FROM coupons ORDER BY id DESC"))


# ------------------------------------------------------------------ reviews
@bp.route("/reviews", methods=["GET", "POST"])
@admin_required
def reviews():
    if request.method == "POST":
        rid, action = to_int(request.form.get("id")), request.form.get("action")
        if action == "approve":
            db.ex("UPDATE reviews SET approved = 1 WHERE id = ?", (rid,))
        elif action == "delete":
            db.ex("DELETE FROM reviews WHERE id = ?", (rid,))
        return redirect(url_for("admin.reviews"))
    rows = db.q("SELECT r.*, p.name AS product, o.order_no FROM reviews r JOIN products p ON p.id = r.product_id "
                "JOIN orders o ON o.id = r.order_id ORDER BY r.approved, r.id DESC LIMIT 100")
    return render_template("admin/reviews.html", reviews=rows)


# ----------------------------------------------------------------- settings
@bp.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
    if request.method == "POST":
        f = request.form
        if f.get("action") == "password":
            user = db.q("SELECT * FROM admins WHERE id = ?", (session["admin_id"],), one=True)
            new = f.get("new_password", "")
            if not check_password_hash(user["password_hash"], f.get("current_password", "")):
                flash("Your current password is wrong.", "error")
            elif len(new) < 8:
                flash("Use at least 8 characters for the new password.", "error")
            elif new != f.get("confirm_password"):
                flash("The two new passwords do not match.", "error")
            else:
                db.ex("UPDATE admins SET password_hash = ? WHERE id = ?", (generate_password_hash(new), user["id"]))
                flash("Password changed.", "success")
        else:
            conn = db.get_db()
            for key in SETTING_KEYS:
                value = f.get(key, "").strip()
                if key in NUMERIC_KEYS:
                    value = str(max(0, to_int(value, 0)))
                conn.execute("INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                             (key, value[:2000]))
            conn.commit()
            flash("Settings saved.", "success")
        return redirect(url_for("admin.settings"))
    return render_template("admin/settings.html", groups=SETTING_GROUPS)
