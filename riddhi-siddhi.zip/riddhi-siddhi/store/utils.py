import io
import math
import os
import re
import secrets
from datetime import datetime, timedelta, timezone

from flask import current_app, g, session, url_for

from . import db

IST = timezone(timedelta(hours=5, minutes=30))

STATES = [
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat",
    "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh",
    "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab",
    "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand",
    "West Bengal", "Andaman and Nicobar Islands", "Chandigarh",
    "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Jammu and Kashmir", "Ladakh",
    "Lakshadweep", "Puducherry",
]

SIZE_ORDER = ["XXS", "XS", "S", "M", "L", "XL", "XXL", "2XL", "3XL", "4XL", "5XL", "FREE", "FREE SIZE", "ONE SIZE"]

ORDER_STATUSES = [
    ("awaiting_payment", "Awaiting payment"),
    ("placed", "New order"),
    ("confirmed", "Confirmed"),
    ("packed", "Packed"),
    ("shipped", "Shipped"),
    ("delivered", "Delivered"),
    ("cancelled", "Cancelled"),
    ("returned", "Returned"),
    ("needs_review", "Needs review"),
]
STATUS_LABEL = dict(ORDER_STATUSES)
PAYMENT_STATUSES = [
    ("pending", "Payment pending"),
    ("cod_pending", "Collect on delivery"),
    ("paid", "Paid"),
    ("failed", "Payment failed"),
    ("refund_due", "Refund due"),
    ("refunded", "Refunded"),
]
PAYMENT_LABEL = dict(PAYMENT_STATUSES)
# Orders in these statuses count as sales on the dashboard.
SALE_STATUSES = ("placed", "confirmed", "packed", "shipped", "delivered", "needs_review")


def status_label(key):
    return STATUS_LABEL.get(key) or PAYMENT_LABEL.get(key) or key


# ---------------------------------------------------------------- formatting
def to_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def inr(n):
    """Format a number as Indian rupees with lakh/crore grouping."""
    try:
        n = int(round(float(n)))
    except (TypeError, ValueError):
        return "₹0"
    neg = n < 0
    s = str(abs(n))
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts + [tail])
    return ("-" if neg else "") + "₹" + s


def parse_utc(text):
    try:
        return datetime.strptime(text, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def ist(text, fmt="%d %b %Y, %I:%M %p"):
    dt = parse_utc(text)
    if not dt:
        return ""
    return dt.astimezone(IST).strftime(fmt).replace(" 0", " ").lstrip("0")


def slugify(text):
    s = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return s or "item"


def unique_slug(table, text, exclude_id=None):
    assert table in ("products", "categories")
    base = slugify(text)
    slug, n = base, 2
    while True:
        row = db.q("SELECT id FROM %s WHERE slug = ?" % table, (slug,), one=True)
        if not row or (exclude_id and row["id"] == exclude_id):
            return slug
        slug = "%s-%d" % (base, n)
        n += 1


def normalize_phone(raw):
    digits = re.sub(r"\D", "", raw or "")
    if len(digits) > 10 and digits.startswith("91"):
        digits = digits[2:]
    if len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
    return digits


def valid_phone(digits):
    return bool(re.fullmatch(r"[6-9]\d{9}", digits or ""))


def size_key(size):
    s = (size or "").strip().upper()
    if s in SIZE_ORDER:
        return (0, SIZE_ORDER.index(s), s)
    m = re.match(r"^(\d+)", s)
    if m:
        return (1, int(m.group(1)), s)
    return (2, 0, s)


def paginate(total, page, per):
    pages = max(1, math.ceil(total / per))
    return dict(page=min(max(1, page), pages), pages=pages, per=per, total=total)


# ------------------------------------------------------------------ security
def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    session.permanent = True
    return session["_csrf"]


# ----------------------------------------------------------------- settings
def get_settings():
    if "settings" not in g:
        g.settings = {r["key"]: r["value"] for r in db.q("SELECT key, value FROM settings")}
    return g.settings


def sint(key, default=0):
    return to_int(get_settings().get(key, default), default)


def wa_number():
    digits = re.sub(r"\D", "", get_settings().get("whatsapp", "") or "")
    if not digits:
        return ""
    return digits if len(digits) > 10 else "91" + digits


def nav_categories():
    if "nav_cats" not in g:
        g.nav_cats = db.q(
            "SELECT id, name, slug FROM categories ORDER BY sort, name"
        )
    return g.nav_cats


def media_url(filename):
    return url_for("shop.media", filename=filename)


def razorpay_enabled():
    return bool(current_app.config["RAZORPAY_KEY_ID"] and current_app.config["RAZORPAY_KEY_SECRET"])


def dispatch_info():
    """Real same-day dispatch countdown based on the cut-off hour in settings (IST)."""
    hour = sint("dispatch_cutoff_hour", 16)
    if hour <= 0:
        return None
    now = datetime.now(IST)
    cutoff = now.replace(hour=min(hour, 23), minute=0, second=0, microsecond=0)
    if now < cutoff:
        return {"today": True, "ms": int(cutoff.timestamp() * 1000), "hour": hour}
    return {"today": False, "ms": 0, "hour": hour}


# ----------------------------------------------------------------- products
PRODUCT_COLS = """
  p.*, c.name AS category_name, c.slug AS category_slug,
  (SELECT filename FROM images WHERE product_id = p.id ORDER BY sort, id LIMIT 1) AS image,
  (SELECT COALESCE(SUM(stock), 0) FROM variants WHERE product_id = p.id) AS stock,
  (SELECT COALESCE(SUM(oi.qty), 0) FROM order_items oi JOIN orders o ON o.id = oi.order_id
     WHERE oi.product_id = p.id AND o.status IN ('placed','confirmed','packed','shipped','delivered')) AS sold,
  (SELECT COALESCE(SUM(oi.qty), 0) FROM order_items oi JOIN orders o ON o.id = oi.order_id
     WHERE oi.product_id = p.id AND o.status IN ('placed','confirmed','packed','shipped','delivered')
       AND o.created_at >= datetime('now', '-7 day')) AS sold_week,
  (SELECT ROUND(AVG(rating), 1) FROM reviews WHERE product_id = p.id AND approved = 1) AS rating,
  (SELECT COUNT(*) FROM reviews WHERE product_id = p.id AND approved = 1) AS review_count
"""

SORTS = {
    "new": "(stock > 0) DESC, id DESC",
    "popular": "(stock > 0) DESC, sold DESC, id DESC",
    "price_asc": "(stock > 0) DESC, price ASC",
    "price_desc": "(stock > 0) DESC, price DESC",
}


def decorate(row):
    p = dict(row)
    mrp, price = p.get("mrp") or 0, p.get("price") or 0
    p["off_pct"] = int(round((mrp - price) * 100 / mrp)) if mrp > price > 0 else 0
    p["saving"] = max(0, mrp - price)
    stock = p.get("stock", 0) or 0
    created = parse_utc(p.get("created_at"))
    is_new = bool(created and (datetime.now(timezone.utc) - created) < timedelta(days=14))
    thr = sint("low_stock_threshold", 5)
    badge = None
    if "stock" in p:
        if stock <= 0:
            badge = ("Sold out", "out")
        elif stock <= thr:
            badge = ("Only %d left" % stock, "low")
        elif (p.get("sold_week") or 0) >= 3:
            badge = ("Selling fast", "hot")
        elif is_new:
            badge = ("New", "new")
    p["badge"] = badge
    return p


def product_query(where="1=1", args=(), order="id DESC", limit=None, offset=0, active_only=True):
    inner = "SELECT %s FROM products p LEFT JOIN categories c ON c.id = p.category_id" % PRODUCT_COLS
    if active_only:
        inner += " WHERE p.is_active = 1"
    sql = "SELECT * FROM (%s) t WHERE %s ORDER BY %s" % (inner, where, order)
    if limit:
        sql += " LIMIT %d OFFSET %d" % (int(limit), int(offset))
    return [decorate(r) for r in db.q(sql, args)]


def product_count(where="1=1", args=(), active_only=True):
    inner = "SELECT %s FROM products p LEFT JOIN categories c ON c.id = p.category_id" % PRODUCT_COLS
    if active_only:
        inner += " WHERE p.is_active = 1"
    return db.q("SELECT COUNT(*) AS n FROM (%s) t WHERE %s" % (inner, where), args, one=True)["n"]


def sorted_variants(rows):
    return sorted(rows, key=lambda v: (size_key(v["size"]), v["color"].lower()))


# --------------------------------------------------------------------- cart
def cart_count():
    return sum(int(v) for v in session.get("cart", {}).values())


def cart_lines():
    cart = session.get("cart", {})
    if not cart:
        return []
    try:
        ids = [int(k) for k in cart]
    except ValueError:
        session["cart"] = {}
        return []
    marks = ",".join("?" * len(ids))
    rows = db.q(
        """SELECT v.id AS vid, v.size, v.color, v.stock, p.id AS pid, p.name, p.slug, p.price, p.mrp, p.is_active,
                  (SELECT filename FROM images WHERE product_id = p.id ORDER BY sort, id LIMIT 1) AS image
           FROM variants v JOIN products p ON p.id = v.product_id WHERE v.id IN (%s)""" % marks,
        ids,
    )
    by_id = {r["vid"]: r for r in rows}
    lines, cleaned = [], {}
    for key, wanted in cart.items():
        r = by_id.get(int(key))
        if not r:
            continue  # variant was deleted; drop it from the cart
        cleaned[key] = wanted
        wanted = int(wanted)
        qty = min(wanted, r["stock"])
        available = bool(r["is_active"]) and r["stock"] > 0
        line = dict(r)
        line.update(
            qty=qty if available else 0,
            wanted=wanted,
            available=available,
            line_total=r["price"] * (qty if available else 0),
        )
        lines.append(line)
    if cleaned != cart:
        session["cart"] = cleaned
    return lines


def ok_lines(lines):
    return [l for l in lines if l["available"] and l["qty"] > 0]


# ------------------------------------------------------------------ pricing
def validate_coupon(code, subtotal):
    code = (code or "").strip().upper()
    if not code:
        return None, None
    c = db.q("SELECT * FROM coupons WHERE code = ?", (code,), one=True)
    if not c or not c["active"]:
        return None, "That coupon code is not valid."
    if c["expires"] and c["expires"] < datetime.now(IST).strftime("%Y-%m-%d"):
        return None, "This coupon has expired."
    if c["uses_limit"] and c["used_count"] >= c["uses_limit"]:
        return None, "This coupon has been fully redeemed."
    if subtotal < c["min_order"]:
        return None, "Add %s more to use this coupon (minimum order %s)." % (
            inr(c["min_order"] - subtotal), inr(c["min_order"]))
    return c, None


def price_order(lines, coupon_code=None, method=None):
    """Single source of truth for order totals. Always computed on the server."""
    subtotal = sum(l["line_total"] for l in lines)
    coupon, coupon_error = validate_coupon(coupon_code, subtotal) if lines else (None, None)
    discount = 0
    if coupon:
        if coupon["kind"] == "percent":
            discount = int(subtotal * coupon["value"] / 100)
            if coupon["max_discount"]:
                discount = min(discount, coupon["max_discount"])
        else:
            discount = coupon["value"]
        discount = max(0, min(discount, subtotal))
    after = subtotal - discount
    pct = sint("prepaid_discount_pct", 0)
    prepaid_saving = int(after * pct / 100)
    prepaid = prepaid_saving if method == "razorpay" else 0
    free_above = sint("free_shipping_above", 0)
    shipping = 0 if (not lines or after >= free_above) else sint("shipping_fee", 0)
    cod_fee = sint("cod_fee", 0) if method == "cod" else 0
    return dict(
        subtotal=subtotal,
        discount=discount,
        coupon=coupon,
        coupon_error=coupon_error,
        prepaid_discount=prepaid,
        prepaid_saving=prepaid_saving,
        shipping=shipping,
        cod_fee=cod_fee,
        total=after - prepaid + shipping + cod_fee,
        free_gap=max(0, free_above - after) if free_above and lines else 0,
        free_above=free_above,
    )


# ------------------------------------------------------------------- images
def _sniff(data):
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    return None


def save_image(file_storage):
    """Validate, shrink and store an uploaded product photo. Returns the stored filename."""
    data = file_storage.read()
    if not data:
        raise ValueError("The image file was empty.")
    if len(data) > 8 * 1024 * 1024:
        raise ValueError("Each image must be under 8 MB.")
    kind = _sniff(data)
    if not kind:
        raise ValueError("Only JPG, PNG or WebP images can be uploaded.")
    name = secrets.token_hex(12)
    folder = current_app.config["UPLOAD_DIR"]
    try:
        from PIL import Image, ImageOps
    except ImportError:
        filename = "%s.%s" % (name, kind)
        with open(os.path.join(folder, filename), "wb") as fh:
            fh.write(data)
        return filename
    try:
        im = Image.open(io.BytesIO(data))
        im = ImageOps.exif_transpose(im)
        im.thumbnail((1400, 1400))
        if im.mode not in ("RGB", "RGBA"):
            im = im.convert("RGB")
        filename = name + ".webp"
        im.save(os.path.join(folder, filename), "WEBP", quality=82)
    except Exception:
        raise ValueError("That image could not be read. Try saving it again as JPG or PNG.")
    return filename


def delete_image_file(filename):
    if not filename or "/" in filename or "\\" in filename:
        return
    try:
        os.remove(os.path.join(current_app.config["UPLOAD_DIR"], filename))
    except OSError:
        pass
