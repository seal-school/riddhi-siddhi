import os
import secrets
from datetime import timedelta

import click
from flask import Flask, abort, render_template, request, session
from markupsafe import Markup
from werkzeug.middleware.proxy_fix import ProxyFix

from . import db, utils


def _load_env(path):
    """Tiny .env loader so the project needs no extra packages."""
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def create_app(test_config=None):
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _load_env(os.path.join(root, ".env"))

    app = Flask(
        __name__,
        static_folder=os.path.join(root, "static"),
        template_folder=os.path.join(root, "templates"),
    )

    data_dir = os.environ.get("DATA_DIR", os.path.join(root, "data"))
    os.makedirs(data_dir, exist_ok=True)

    secret = os.environ.get("SECRET_KEY")
    if not secret:
        key_file = os.path.join(data_dir, ".secret_key")
        if os.path.exists(key_file):
            with open(key_file) as fh:
                secret = fh.read().strip()
        else:
            secret = secrets.token_hex(32)
            with open(key_file, "w") as fh:
                fh.write(secret)

    app.config.update(
        SECRET_KEY=secret,
        DATABASE=os.path.join(data_dir, "riddhi_siddhi.db"),
        UPLOAD_DIR=os.environ.get("UPLOAD_DIR", os.path.join(data_dir, "uploads")),
        MAX_CONTENT_LENGTH=30 * 1024 * 1024,
        PERMANENT_SESSION_LIFETIME=timedelta(days=30),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "0") == "1",
        RAZORPAY_KEY_ID=os.environ.get("RAZORPAY_KEY_ID", ""),
        RAZORPAY_KEY_SECRET=os.environ.get("RAZORPAY_KEY_SECRET", ""),
        RAZORPAY_WEBHOOK_SECRET=os.environ.get("RAZORPAY_WEBHOOK_SECRET", ""),
        SITE_URL=os.environ.get("SITE_URL", "").rstrip("/"),
    )
    if test_config:
        app.config.update(test_config)
    os.makedirs(app.config["UPLOAD_DIR"], exist_ok=True)

    if os.environ.get("TRUST_PROXY") == "1":
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    db.init_app(app)
    with app.app_context():
        db.init_db()
        db.ensure_admin()

    # ---- template helpers -------------------------------------------------
    app.jinja_env.filters["inr"] = utils.inr
    app.jinja_env.filters["ist"] = utils.ist
    app.jinja_env.globals.update(
        media_url=utils.media_url,
        status_label=utils.status_label,
        csrf_field=lambda: Markup(
            '<input type="hidden" name="csrf_token" value="%s">' % utils.csrf_token()
        ),
        csrf_token=utils.csrf_token,
    )

    @app.context_processor
    def inject():
        return dict(
            settings=utils.get_settings(),
            nav_categories=utils.nav_categories(),
            cart_count=utils.cart_count(),
            razorpay_enabled=utils.razorpay_enabled(),
            wa_number=utils.wa_number(),
            order_statuses=utils.ORDER_STATUSES,
        )

    # ---- security ---------------------------------------------------------
    @app.before_request
    def csrf_protect():
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            if request.endpoint in ("shop.razorpay_webhook", "shop.payment_verify"):
                return  # authenticated by Razorpay signature instead
            token = session.get("_csrf")
            sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")
            if not token or not sent or not secrets.compare_digest(token, sent):
                abort(400, "Your session expired. Please go back, refresh the page and try again.")

    @app.after_request
    def headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if app.config["SESSION_COOKIE_SECURE"]:
            resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
        if request.path.startswith("/admin"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    # ---- errors -----------------------------------------------------------
    def _error(code, title, message):
        return render_template("error.html", code=code, title=title, message=message), code

    @app.errorhandler(404)
    def e404(e):
        return _error(404, "We couldn't find that page", "The link may be old, or the product may no longer be available.")

    @app.errorhandler(400)
    def e400(e):
        return _error(400, "Something went wrong", getattr(e, "description", "Please go back and try again."))

    @app.errorhandler(413)
    def e413(e):
        return _error(413, "That file is too large", "Please upload images smaller than 5 MB each.")

    @app.errorhandler(500)
    def e500(e):
        return _error(500, "We hit a problem", "Please try again in a moment. If it keeps happening, contact us.")

    @app.get("/healthz")
    def healthz():
        db.q("SELECT 1")
        return "ok"

    # ---- blueprints -------------------------------------------------------
    from . import admin, shop

    app.register_blueprint(shop.bp)
    app.register_blueprint(admin.bp, url_prefix="/admin")

    # ---- CLI --------------------------------------------------------------
    @app.cli.command("seed")
    def seed_cmd():
        """Load sample categories, products and a welcome coupon."""
        from .seed import seed

        click.echo(seed())

    @app.cli.command("reset-admin")
    @click.option("--username", default="admin", show_default=True)
    @click.password_option()
    def reset_admin(username, password):
        """Create or reset an admin login."""
        if len(password) < 8:
            raise click.ClickException("Use at least 8 characters.")
        db.set_admin_password(username, password)
        click.echo("Admin login saved for '%s'." % username)

    return app
