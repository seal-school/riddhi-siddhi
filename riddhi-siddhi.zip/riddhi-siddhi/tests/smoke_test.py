"""End to end smoke test: python tests/smoke_test.py"""
import os, re, sys, tempfile, json, hmac, hashlib, io

tmp = tempfile.mkdtemp()
os.environ["DATA_DIR"] = tmp
os.environ["ADMIN_USERNAME"] = "owner"
os.environ["ADMIN_PASSWORD"] = "correct-horse-1"
os.environ["RAZORPAY_KEY_ID"] = "rzp_test_x"
os.environ["RAZORPAY_KEY_SECRET"] = "secret123"
os.environ["RAZORPAY_WEBHOOK_SECRET"] = "whsec"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from store import create_app, db, payments
from store.seed import seed

app = create_app()
payments.create_order = lambda amount, receipt: {"id": "order_TEST%s" % receipt}
fails = []

def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + ((" :: " + str(extra)) if (extra and not cond) else ""))
    if not cond:
        fails.append(name)

def token(c, path="/"):
    html = c.get(path).get_data(as_text=True)
    m = re.search(r'name="csrf_token" value="([a-f0-9]+)"', html)
    return m.group(1) if m else None

with app.app_context():
    print(seed())

c = app.test_client()
for path in ["/", "/shop", "/shop?category=women", "/shop?sale=1", "/shop?q=kurti", "/shop?size=M&sort=price_asc",
             "/cart", "/track", "/about", "/shipping-returns", "/privacy", "/contact", "/robots.txt", "/sitemap.xml", "/healthz"]:
    r = c.get(path)
    check("GET " + path, r.status_code == 200, r.status_code)
r = c.get("/product/cotton-straight-kurti")
check("product page", r.status_code == 200 and b"Add to cart" in r.data)
check("footer credit", b"Built by SEAL" in c.get("/").data)
check("404", c.get("/product/nope").status_code == 404)

# CSRF enforced
check("csrf blocks", c.post("/cart/add", data={"variant_id": 1}).status_code == 400)

with app.app_context():
    v = db.q("SELECT v.id, v.stock FROM variants v JOIN products p ON p.id=v.product_id WHERE p.slug='cotton-straight-kurti' AND size='M' AND color='Indigo'", one=True)
    vid, stock0 = v["id"], v["stock"]

t = token(c, "/product/cotton-straight-kurti")
r = c.post("/cart/add", data={"csrf_token": t, "variant_id": vid, "qty": 2, "slug": "cotton-straight-kurti", "action": "add"}, follow_redirects=True)
check("add to cart", r.status_code == 200 and b"Added to your cart" in r.data)
check("cart shows free shipping bar", b"free shipping" in r.data.lower())
t = token(c, "/cart")
r = c.post("/cart/coupon", data={"csrf_token": t, "code": "welcome10", "next": "/cart"}, follow_redirects=True)
check("coupon applied", b"Coupon WELCOME10 applied" in r.data)
r = c.post("/cart/coupon", data={"csrf_token": t, "code": "BOGUS", "next": "/cart"}, follow_redirects=True)
check("bad coupon rejected", b"not valid" in r.data)

r = c.get("/checkout")
check("checkout page", r.status_code == 200 and b"Pay online" in r.data and b"Cash on delivery" in r.data)
t = token(c, "/checkout")
r = c.post("/checkout", data={"csrf_token": t, "name": "A", "phone": "123", "address": "x", "city": "", "state": "", "pincode": "12", "payment_method": "cod"})
check("checkout validation", r.status_code == 200 and b"Enter a 10 digit mobile" in r.data)

form = {"csrf_token": t, "name": "Asha Rao", "phone": "+91 98765 43210", "email": "asha@example.com",
        "address": "12 MG Road, Indiranagar", "city": "Bengaluru", "state": "Karnataka", "pincode": "560038", "payment_method": "cod"}
r = c.post("/checkout", data=form, follow_redirects=False)
check("COD order placed", r.status_code == 302 and "/order/RS" in r.headers["Location"], r.headers.get("Location"))
order_url = r.headers["Location"]
r = c.get(order_url)
check("order page thank you", b"Your order is in" in r.data)
with app.app_context():
    o = db.q("SELECT * FROM orders ORDER BY id DESC LIMIT 1", one=True)
    stock1 = db.q("SELECT stock FROM variants WHERE id=?", (vid,), one=True)["stock"]
    check("COD totals", o["subtotal"] == 1598 and o["discount"] == 159 and o["cod_fee"] == 49 and o["shipping"] == 0 and o["total"] == 1598 - 159 + 49, dict(o))
    check("stock reserved", stock1 == stock0 - 2, (stock0, stock1))
    order_no, oid = o["order_no"], o["id"]

# track from a fresh browser
c2 = app.test_client()
t2 = token(c2, "/track")
r = c2.post("/track", data={"csrf_token": t2, "order_no": order_no.lower(), "phone": "9876543210"}, follow_redirects=True)
check("track ok", r.status_code == 200 and order_no.encode() in r.data)
r = c2.post("/track", data={"csrf_token": t2, "order_no": order_no, "phone": "9000000000"}, follow_redirects=True)
check("track wrong phone", b"could not find" in r.data)
check("order private", app.test_client().get("/order/" + order_no).status_code == 404)

# Online payment flow
c3 = app.test_client()
t3 = token(c3, "/product/classic-oxford-shirt")
with app.app_context():
    v2 = db.q("SELECT v.id, v.stock FROM variants v JOIN products p ON p.id=v.product_id WHERE p.slug='classic-oxford-shirt' AND size='40' AND color='White'", one=True)
c3.post("/cart/add", data={"csrf_token": t3, "variant_id": v2["id"], "qty": 1, "slug": "x", "action": "buy"})
t3 = token(c3, "/checkout")
form2 = dict(form, csrf_token=t3, payment_method="razorpay")
r = c3.post("/checkout", data=form2)
check("online order -> pay", r.status_code == 302 and "/pay/RS" in r.headers["Location"], r.headers.get("Location"))
r = c3.get(r.headers["Location"])
check("pay page", r.status_code == 200 and b"order_TEST" in r.data)
with app.app_context():
    o2 = db.q("SELECT * FROM orders ORDER BY id DESC LIMIT 1", one=True)
    check("online discount 5%", o2["prepaid_discount"] == 49 and o2["total"] == 999 - 49 and o2["status"] == "awaiting_payment", dict(o2))
rp_order = o2["razorpay_order_id"]
bad = c3.post("/payment/verify", json={"razorpay_order_id": rp_order, "razorpay_payment_id": "pay_1", "razorpay_signature": "bad"})
check("bad signature rejected", bad.status_code == 400)
sig = hmac.new(b"secret123", ("%s|pay_1" % rp_order).encode(), hashlib.sha256).hexdigest()
good = c3.post("/payment/verify", json={"razorpay_order_id": rp_order, "razorpay_payment_id": "pay_1", "razorpay_signature": sig})
check("good signature accepted", good.status_code == 200 and good.get_json()["ok"])
with app.app_context():
    o2 = db.q("SELECT * FROM orders WHERE id=?", (o2["id"],), one=True)
    check("marked paid", o2["payment_status"] == "paid" and o2["status"] == "placed")
body = json.dumps({"event": "payment.captured", "payload": {"payment": {"entity": {"id": "pay_1", "order_id": rp_order}}}}).encode()
wsig = hmac.new(b"whsec", body, hashlib.sha256).hexdigest()
check("webhook bad sig", app.test_client().post("/webhooks/razorpay", data=body, headers={"X-Razorpay-Signature": "x"}).status_code == 400)
check("webhook ok (idempotent)", app.test_client().post("/webhooks/razorpay", data=body, headers={"X-Razorpay-Signature": wsig}).status_code == 200)

# Expiry releases stock
c4 = app.test_client()
t4 = token(c4, "/track")
c4.post("/cart/add", data={"csrf_token": t4, "variant_id": v2["id"], "qty": 1, "slug": "x"})
t4 = token(c4, "/checkout")
r = c4.post("/checkout", data=dict(form2, csrf_token=t4))
with app.app_context():
    before = db.q("SELECT stock FROM variants WHERE id=?", (v2["id"],), one=True)["stock"]
    db.ex("UPDATE orders SET created_at=datetime('now','-2 hour') WHERE status='awaiting_payment'")
    from store import orders as om
    om.release_expired()
    after = db.q("SELECT stock FROM variants WHERE id=?", (v2["id"],), one=True)["stock"]
    check("expired order returns stock", after == before + 1, (before, after))

# Out of stock race
with app.app_context():
    db.ex("UPDATE variants SET stock=1 WHERE id=?", (v2["id"],))
c5, c6 = app.test_client(), app.test_client()
for cl in (c5, c6):
    tk = token(cl, "/track")
    cl.post("/cart/add", data={"csrf_token": tk, "variant_id": v2["id"], "qty": 1, "slug": "x"})
r5 = c5.post("/checkout", data=dict(form, csrf_token=token(c5, "/checkout")))
r6 = c6.post("/checkout", data=dict(form, csrf_token=token(c6, "/checkout")), follow_redirects=True)
check("first buyer gets last unit", r5.status_code == 302)
check("second buyer told it sold out", b"sold out" in r6.data.lower() or b"review your cart" in r6.data.lower())

# ---------------- admin
a = app.test_client()
check("admin redirects when logged out", a.get("/admin/").status_code == 302)
ta = token(a, "/admin/login")
r = a.post("/admin/login", data={"csrf_token": ta, "username": "owner", "password": "nope"})
check("bad login", b"Wrong username" in r.data)
r = a.post("/admin/login", data={"csrf_token": ta, "username": "owner", "password": "correct-horse-1"})
check("login", r.status_code == 302)
for path in ["/admin/", "/admin/products", "/admin/products/new", "/admin/products/1/edit", "/admin/inventory",
             "/admin/inventory?status=low", "/admin/orders", "/admin/orders?status=placed", f"/admin/orders/{oid}",
             f"/admin/orders/{oid}/invoice", "/admin/categories", "/admin/coupons", "/admin/reviews", "/admin/settings",
             "/admin/import", "/admin/export/orders.csv", "/admin/export/products.csv", "/admin/import/sample.csv"]:
    r = a.get(path)
    check("GET " + path, r.status_code == 200, r.status_code)

ta = token(a, f"/admin/orders/{oid}")
r = a.post(f"/admin/orders/{oid}/update", data={"csrf_token": ta, "status": "shipped", "courier": "India Post", "tracking_no": "EE123", "admin_note": ""}, follow_redirects=True)
check("ship order", b"Order updated" in r.data)
r = a.post(f"/admin/orders/{oid}/update", data={"csrf_token": ta, "status": "delivered", "courier": "India Post", "tracking_no": "EE123", "admin_note": ""}, follow_redirects=True)
with app.app_context():
    o = db.q("SELECT * FROM orders WHERE id=?", (oid,), one=True)
    check("COD marked paid on delivery", o["payment_status"] == "paid" and o["status"] == "delivered")
# customer review flow
rv = c.post("/review", data={"csrf_token": token(c, order_url), "order_no": order_no, "product_id": 1, "rating": 5, "comment": "Lovely fit"}, follow_redirects=True)
check("review submitted", b"Thank you" in rv.data)
a.post("/admin/reviews", data={"csrf_token": ta, "id": 1, "action": "approve"})
check("review visible", b"Lovely fit" in c.get("/product/cotton-straight-kurti").data)

# cancel restores stock
with app.app_context():
    o3 = db.q("SELECT * FROM orders WHERE order_no != ? AND status='placed' ORDER BY id LIMIT 1", (order_no,), one=True)
    s_before = db.q("SELECT stock FROM variants WHERE id=?", (v2["id"],), one=True)["stock"]
r = a.post(f"/admin/orders/{o3['id']}/update", data={"csrf_token": ta, "status": "cancelled", "courier": "", "tracking_no": "", "admin_note": ""}, follow_redirects=True)
with app.app_context():
    s_after = db.q("SELECT stock FROM variants WHERE id=?", (v2["id"],), one=True)["stock"]
    o3n = db.q("SELECT * FROM orders WHERE id=?", (o3["id"],), one=True)
    check("cancel restores stock", s_after == s_before + 1, (s_before, s_after))
    check("paid online cancel -> refund due", o3n["payment_status"] in ("refund_due", "cod_pending", "paid"))

# product create with image + variants
import struct, zlib
def png():
    raw = b"\x00\xff\x00\x00" * 8
    raw = b"".join(b"\x00" + b"\xff\x00\x00" * 8 for _ in range(8))
    def chunk(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 8, 8, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
ta = token(a, "/admin/products/new")
data = {"csrf_token": ta, "name": "Test Saree", "category_id": "1", "price": "1500", "mrp": "2500", "description": "d", "fabric_care": "",
        "is_active": "1", "v_id": ["0", "0"], "v_size": ["Free", "Free"], "v_color": ["Red", "Blue"], "v_sku": ["", ""], "v_stock": ["5", "7"],
        "images": (io.BytesIO(png()), "a.png")}
r = a.post("/admin/products/new", data=data, content_type="multipart/form-data", follow_redirects=True)
check("create product", b"Product saved" in r.data, r.data[:300] if b"Product saved" not in r.data else "")
with app.app_context():
    p = db.q("SELECT * FROM products WHERE name='Test Saree'", one=True)
    imgs = db.q("SELECT * FROM images WHERE product_id=?", (p["id"],))
    check("image stored", len(imgs) == 1 and os.path.exists(os.path.join(app.config["UPLOAD_DIR"], imgs[0]["filename"])))
r = a.get(f"/media/{imgs[0]['filename']}")
check("media served", r.status_code == 200)
check("storefront shows new product", b"Test Saree" in c.get("/shop").data)
r = a.post("/admin/products/new", data=dict(data, v_size=["M", "M"], v_color=["", ""], images=(io.BytesIO(b"x"), "")), content_type="multipart/form-data")
check("duplicate variant rejected", r.status_code == 400)

# stock edit
ta = token(a, "/admin/inventory")
with app.app_context():
    vv = db.q("SELECT id FROM variants WHERE product_id=?", (p["id"],), one=True)["id"]
r = a.post("/admin/inventory", data={"csrf_token": ta, "reason": "count", f"stock_{vv}": "99"}, follow_redirects=True)
with app.app_context():
    check("inventory edit", db.q("SELECT stock FROM variants WHERE id=?", (vv,), one=True)["stock"] == 99)

# CSV import
csv_text = "name,category,price,mrp,size,color,stock,sku,description\nImport Tee,Men,399,599,M,Black,10,IT-M,Nice\nImport Tee,Men,399,599,L,Black,5,IT-L,\nBad row,,0,,,,x,,\n"
ta = token(a, "/admin/import")
r = a.post("/admin/import", data={"csrf_token": ta, "mode": "set", "file": (io.BytesIO(csv_text.encode()), "x.csv")}, content_type="multipart/form-data")
check("csv import", b"1 new product" in r.data and b"2 new size" in r.data and b"Row 4 skipped" in r.data, r.data[-600:])
r = a.post("/admin/import", data={"csrf_token": ta, "mode": "add", "file": (io.BytesIO(csv_text.encode()), "x.csv")}, content_type="multipart/form-data")
with app.app_context():
    check("csv add mode", db.q("SELECT stock FROM variants WHERE sku='IT-M'", one=True)["stock"] == 20)

# coupon + settings + category
ta = token(a, "/admin/coupons")
r = a.post("/admin/coupons", data={"csrf_token": ta, "action": "add", "code": "flat100", "kind": "flat", "value": "100", "min_order": "500"}, follow_redirects=True)
check("coupon create", b"FLAT100" in r.data)
r = a.post("/admin/settings", data={"csrf_token": ta, "store_name": "Riddhi Siddhi", "shipping_fee": "60", "free_shipping_above": "1200"}, follow_redirects=True)
check("settings save", b"Settings saved" in r.data)
r = a.post("/admin/settings", data={"csrf_token": ta, "action": "password", "current_password": "correct-horse-1", "new_password": "new-pass-1234", "confirm_password": "new-pass-1234"}, follow_redirects=True)
check("password change", b"Password changed" in r.data)
r = a.get("/admin/export/orders.csv")
check("orders csv has data", b"RS" in r.data and b"Asha Rao" in r.data)

print("\nFAILED:" if fails else "\nALL PASSED", fails if fails else "")
sys.exit(1 if fails else 0)
