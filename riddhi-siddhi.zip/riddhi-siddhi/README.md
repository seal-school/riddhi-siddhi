# Riddhi Siddhi online store

A complete clothing store with two sides:

- **Storefront** (`/`): browse, search, size and colour picker, cart, coupons, guest checkout, Razorpay or cash on delivery, order tracking, reviews.
- **Admin** (`/admin`): dashboard, orders, products with photos, stock control, bulk CSV import, categories, coupons, review approval, settings, invoices.

Built by SEAL&trade; (shown in the footer of every page).

## Run it on your computer

```bash
python3 -m venv venv && source venv/bin/activate     # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # then edit .env
flask --app wsgi seed                                 # optional sample products
python wsgi.py                                        # http://127.0.0.1:5000
```

Admin is at `/admin`. On first start the login comes from `ADMIN_USERNAME` and `ADMIN_PASSWORD` in `.env`
(or a random password is printed in the terminal). Change it under Settings. Forgot it:
`flask --app wsgi reset-admin --username owner`.

Run the tests any time: `python tests/smoke_test.py`.

## First things to do in Admin

1. **Settings**: add phone, WhatsApp number, address, GSTIN, shipping fee and free shipping level.
2. **Categories**: create the menu (for example Women, Men, Kids, Sarees).
3. **Products**: add photos, sizes, colours and stock. For hundreds of items use **Bulk import** with a spreadsheet.
4. Delete the sample products and the sample coupon (WELCOME10) if you loaded them.
5. Review the Shipping and returns and Privacy wording (`templates/info.html`) and the about text (Settings). Add your legal business details as required for online sellers in India.

## Online payments with Razorpay

1. Create a Razorpay account and complete KYC. Copy the Key ID and Key Secret into `.env`.
2. In Razorpay Dashboard > Webhooks add `https://YOUR-SITE/webhooks/razorpay`, choose events `payment.captured` and `order.paid`, set a secret and put it in `RAZORPAY_WEBHOOK_SECRET`.
3. Keep payment capture on automatic (Dashboard > Settings > Payment Capture).
4. Test with `rzp_test_` keys first, then switch to live keys.

How it stays safe: totals are always calculated on the server; the browser only opens Razorpay's window. A payment is accepted only after its signature is verified, and the webhook marks the order paid even if the customer closes the tab. Stock is held for 45 minutes for unpaid online orders, then returned automatically.

## Putting it online

Pick one:

- **VPS (recommended for a shop)**: `docker compose up -d --build` after filling `.env`. Put Caddy or nginx in front for https and set `SESSION_COOKIE_SECURE=1`, `TRUST_PROXY=1` and `SITE_URL`.
- **Render, Railway, Fly.io**: deploy this folder; the start command is in `Procfile`. Attach a persistent disk and set `DATA_DIR` to it, otherwise the database and photos are lost on redeploy.

**Back up the `DATA_DIR` folder** (database `riddhi_siddhi.db` and `uploads/`) daily.

## How it helps customers decide (all genuine, nothing faked)

- Price anchoring: MRP crossed out, percent off and the exact rupees saved.
- Real scarcity: "Only N left" appears only when stock is genuinely low.
- Real social proof: units sold, "selling fast" from the last 7 days of orders, verified buyer reviews (only after an order ships, approved by you).
- Free shipping progress bar and "add a little more" suggestions in the cart.
- Extra discount for paying online and a COD fee, which nudges customers to prepay and cuts return risk.
- Same day dispatch countdown based on your real cut-off time.
- Risk reducers: return window, secure payment, cash on delivery, WhatsApp help button.
- Fewer steps: guest checkout on one page, saved details for repeat orders, sticky Add to cart on phones, Buy now button.

## Project layout

```
store/        Python code (shop.py customer side, admin.py management side, orders.py stock and payments, utils.py pricing)
templates/    HTML pages (admin/ for the management side)
static/       CSS and JavaScript
tests/        smoke_test.py
```

## Good to know

- The database is SQLite, which comfortably handles a busy single shop. If you outgrow it, the queries are plain SQL and move to PostgreSQL easily.
- Customers are not emailed or messaged automatically. The admin order page has WhatsApp buttons that open a ready message to the customer. Automatic SMS or WhatsApp needs a provider account and is a good next step.
- Refunds are done from the Razorpay dashboard; the order is flagged "Refund due" so you do not forget.
- The login throttle is per server process. If you run several workers, add rate limiting at nginx or Caddy as well.
