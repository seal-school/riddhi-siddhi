(function () {
  'use strict';

  document.querySelectorAll('[data-autosubmit]').forEach(function (el) {
    el.addEventListener('change', function () { if (el.form) el.form.submit(); });
  });

  // Confirm destructive actions
  document.addEventListener('submit', function (e) {
    var form = e.target;
    var submitter = e.submitter;
    var msg = (submitter && submitter.getAttribute('data-confirm')) || form.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) e.preventDefault();
  });

  // Variant rows on the product form
  var table = document.getElementById('variants');
  if (table) {
    var body = table.querySelector('tbody');
    var tpl = document.getElementById('row-tpl');
    function addRow(size, color, stock) {
      var node = tpl.content.firstElementChild.cloneNode(true);
      node.querySelector('[name=v_size]').value = size || '';
      node.querySelector('[name=v_color]').value = color || '';
      node.querySelector('[name=v_stock]').value = stock || 0;
      body.appendChild(node);
      return node;
    }
    function exists(size, color) {
      return [].slice.call(body.querySelectorAll('tr')).some(function (tr) {
        return tr.querySelector('[name=v_size]').value.trim().toLowerCase() === size.toLowerCase() &&
               tr.querySelector('[name=v_color]').value.trim().toLowerCase() === color.toLowerCase();
      });
    }
    document.getElementById('add-row').addEventListener('click', function () {
      addRow().querySelector('[name=v_size]').focus();
    });
    table.addEventListener('click', function (e) {
      if (e.target.matches('[data-remove-row]')) e.target.closest('tr').remove();
    });
    document.getElementById('gen-btn').addEventListener('click', function () {
      var split = function (v) { return v.split(',').map(function (x) { return x.trim(); }).filter(Boolean); };
      var sizes = split(document.getElementById('gen-sizes').value);
      var colors = split(document.getElementById('gen-colors').value);
      if (!colors.length) colors = [''];
      var stock = parseInt(document.getElementById('gen-stock').value, 10) || 0;
      sizes.forEach(function (s) { colors.forEach(function (c) { if (!exists(s, c)) addRow(s, c, stock); }); });
      document.getElementById('gen-sizes').value = '';
      document.getElementById('gen-colors').value = '';
    });
  }
})();
