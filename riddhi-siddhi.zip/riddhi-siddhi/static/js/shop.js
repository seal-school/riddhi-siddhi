(function () {
  'use strict';

  // Auto-submit filter selects (works without JS too, via the noscript button)
  document.querySelectorAll('[data-autosubmit]').forEach(function (el) {
    el.addEventListener('change', function () { if (el.form) el.form.submit(); });
  });

  // Product gallery
  var mainImg = document.getElementById('main-img');
  document.querySelectorAll('[data-thumb]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      if (mainImg) mainImg.src = btn.getAttribute('data-thumb');
      document.querySelectorAll('[data-thumb]').forEach(function (b) { b.classList.remove('on'); });
      btn.classList.add('on');
    });
  });

  // Quantity stepper
  document.querySelectorAll('[data-step]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.getElementById('qty');
      var max = parseInt(input.max, 10) || 10;
      var next = (parseInt(input.value, 10) || 1) + parseInt(btn.getAttribute('data-step'), 10);
      input.value = Math.max(1, Math.min(max, next));
    });
  });

  // Variant picker: colour and size chips resolve to one variant with its own stock
  var dataEl = document.getElementById('variants-data');
  var form = document.getElementById('buy-form');
  if (dataEl && form) {
    var variants = JSON.parse(dataEl.textContent);
    var threshold = parseInt(document.getElementById('variants-meta').getAttribute('data-threshold'), 10) || 5;
    var vidInput = form.querySelector('[name=variant_id]');
    var msg = document.getElementById('stock-msg');
    var qty = document.getElementById('qty');
    var colorBtns = [].slice.call(form.querySelectorAll('[data-color]'));
    var sizeBtns = [].slice.call(form.querySelectorAll('[data-size]'));
    var colors = variants.map(function (v) { return v.color; }).filter(function (c, i, a) { return a.indexOf(c) === i; });
    var color = colors.length === 1 ? colors[0] : null;
    var size = null;

    function find(s, c) {
      for (var i = 0; i < variants.length; i++) {
        if (variants[i].size === s && variants[i].color === c) return variants[i];
      }
      return null;
    }
    function sizeAvailable(s) {
      return variants.some(function (v) { return v.size === s && v.stock > 0 && (color === null || v.color === color); });
    }
    function refresh() {
      sizeBtns.forEach(function (b) {
        var s = b.getAttribute('data-size');
        b.classList.toggle('on', s === size);
        b.classList.toggle('na', !sizeAvailable(s));
        b.setAttribute('aria-pressed', s === size ? 'true' : 'false');
      });
      colorBtns.forEach(function (b) {
        var c = b.getAttribute('data-color');
        b.classList.toggle('on', c === color);
        b.setAttribute('aria-pressed', c === color ? 'true' : 'false');
      });
      var sl = document.getElementById('size-label'), cl = document.getElementById('color-label');
      if (sl) sl.textContent = size || '';
      if (cl) cl.textContent = color || '';
      var v = (size !== null && color !== null) ? find(size, color) : null;
      vidInput.value = v && v.stock > 0 ? v.id : '';
      msg.className = 'stock-msg';
      if (!v) {
        msg.textContent = colors.length > 1 && color === null ? 'Choose a colour and a size.' : (size === null ? 'Choose a size to see availability.' : 'That combination is not available.');
      } else if (v.stock <= 0) {
        msg.textContent = 'Sold out in this size. Try another.'; msg.className = 'stock-msg warn';
      } else if (v.stock <= threshold) {
        msg.textContent = 'Only ' + v.stock + ' left. Order soon.'; msg.className = 'stock-msg low';
      } else {
        msg.textContent = 'In stock and ready to ship.'; msg.className = 'stock-msg ok';
      }
      if (v) qty.max = Math.min(10, Math.max(1, v.stock));
      if (parseInt(qty.value, 10) > parseInt(qty.max, 10)) qty.value = qty.max;
    }

    sizeBtns.forEach(function (b) {
      b.addEventListener('click', function () {
        size = b.getAttribute('data-size');
        refresh();
      });
    });
    colorBtns.forEach(function (b) {
      b.addEventListener('click', function () { color = b.getAttribute('data-color'); refresh(); });
    });
    form.addEventListener('submit', function (e) {
      if (!vidInput.value) {
        e.preventDefault();
        if (!msg.classList.contains('warn')) {
          msg.textContent = colors.length > 1 && color === null ? 'Please choose a colour and a size.' : 'Please choose an available size.';
          msg.className = 'stock-msg warn';
        }
        var grp = document.getElementById('size-group');
        grp.classList.remove('shake'); void grp.offsetWidth; grp.classList.add('shake');
        grp.scrollIntoView({block: 'center', behavior: 'smooth'});
      }
    });
    // If only one variant exists, pre-select it
    if (variants.length === 1) { size = variants[0].size; color = variants[0].color; }
    refresh();
  }

  // Real dispatch cut-off countdown
  var cd = document.querySelector('[data-countdown]');
  if (cd) {
    var target = parseInt(cd.getAttribute('data-countdown'), 10);
    var tick = function () {
      var left = Math.floor((target - Date.now()) / 1000);
      if (left <= 0) { cd.textContent = 'a moment'; return; }
      var h = Math.floor(left / 3600), m = Math.floor((left % 3600) / 60), s = left % 60;
      cd.textContent = (h ? h + 'h ' : '') + m + 'm ' + (h ? '' : s + 's');
    };
    tick(); setInterval(tick, 1000);
  }

  // Checkout: swap totals when the payment method changes
  var totalsEl = document.getElementById('totals-data');
  if (totalsEl) {
    var totals = JSON.parse(totalsEl.textContent);
    var radios = [].slice.call(document.querySelectorAll('input[name=payment_method]'));
    var place = document.getElementById('place-btn');
    var update = function () {
      var picked = radios.filter(function (r) { return r.checked; })[0];
      var m = picked ? picked.value : 'cod';
      var t = totals[m];
      document.querySelectorAll('.pay-opt').forEach(function (l) {
        l.classList.toggle('is-on', l.querySelector('input').checked);
      });
      document.getElementById('sum-total').textContent = t.total;
      document.getElementById('sum-ship').textContent = t.free ? 'Free' : t.shipping;
      var rp = document.getElementById('row-prepaid'), rc = document.getElementById('row-cod');
      rp.hidden = !t.prepaid; rc.hidden = !t.fee;
      document.getElementById('sum-prepaid').textContent = t.prepaid ? '\u2212' + t.prepaid : '';
      document.getElementById('sum-fee').textContent = t.fee || '';
      place.textContent = m === 'razorpay' ? 'Pay ' + t.total : 'Place order';
    };
    radios.forEach(function (r) { r.addEventListener('change', update); });
    update();
  }

  // Prevent double submits on forms that create orders
  var checkout = document.getElementById('checkout-form');
  if (checkout) {
    checkout.addEventListener('submit', function () {
      var btn = document.getElementById('place-btn');
      if (btn) { btn.disabled = true; btn.textContent = 'Placing your order\u2026'; }
    });
  }
})();
